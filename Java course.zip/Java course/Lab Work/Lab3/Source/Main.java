/**
 * You may remove (comment out) the package name if you want.
 * This main class MUST NOT BE CHANGED. Keep it as it is exactly.
 * No points possible for any changes here
 * and negative points for any modification.
 */
package haw.sol2.exam.ws2015;

import java.io.File;
import java.util.ArrayList;

/**
 * @author Prof. Schoenen
 * Exam 2015.12 (winter term)
 */
public class Main {
	public final static boolean debug = true;

	public static void main(String[] args) {
		System.out.println("Main simulator");
		ArrayList<String> filenames = new ArrayList<String>();
		//int numargs = args.length; // number of program arguments
		// if argument(s) is/are given, use these filenames
		for(int i = 0; i < args.length; i++) {
			String s = args[i];
			System.out.println("-- Arg: "+s+"\n");
            filenames.add(s);
        }
		if (filenames.size()==0) {
			 // file to open if no argument is given
			String defaultFilename = "rc_circuit.net";
			if (debug) System.out.println("No argument given. Using file=\""+defaultFilename+"\".\n");
			filenames.add(defaultFilename);
			String defaultFilename2 = "TwoTau.net";
			if (debug) System.out.println("No argument given. Using file=\""+defaultFilename+"\".\n");
			filenames.add(defaultFilename2);
			// "TwoTau.asc" is the original LTSpice file
		}
		String fileContentString="";
		ArrayList<String> simList = new ArrayList<String>();
		for(String filename : filenames) {
			File file = new File(filename);
			// open file and read into string
			if (file.exists() && file.canRead()) {
				SimFileReader simFileReader = new SimFileReader(file);
				fileContentString = simFileReader.readFile();
				if (debug) System.out.println("FileContents(\""+filename+"\")=\n"+fileContentString);
				if (simFileReader.readWasOK()) simList.add(fileContentString);
			}
		}
		if (simList.isEmpty()) { // if strings are empty
			// initialize string with
			fileContentString ="* this is a comment for the fallback spice file"
					+ "R1 in out 1000"
					+ "C1 out 0 0.000001"
					+ "V1 in 0 PULSE(0 5 0.00001 0.000002 0.000002 0.005 1) AC 1 0"
					+ ".ac oct 10 10 10000"
					+ ".tran 0 0.01 0 0.00001";
			if (debug) System.out.println("DummyFileContents=\n"+fileContentString);
			simList.add(fileContentString);
		}
		int simNumber=1;
		for (String spiceString : simList) {
			if (debug) System.out.println("Simulation set "+simNumber+++":");
			Simulator simulator = new Simulator(); 
			simulator.parse(spiceString);
			simulator.start();
			String resultString = simulator.showResults();
			System.out.println(resultString);
		}
	}

}
