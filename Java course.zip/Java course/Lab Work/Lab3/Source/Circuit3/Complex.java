/**
 * Complex data type class
 */
package haw.so2.circuit3;

/**
 * @author Schoenen
 *
 */
public class Complex {
	private int realInt;
	private int imagInt;
	private double realDbl;
	private double imagDbl;
	private boolean isInt; 
	
	public Complex(int re, int im) {
		realInt=re; imagInt=im; isInt=true;
	}
	public Complex(double re, double im) {
		realDbl=re; imagDbl=im; isInt=false;
	}

	public static Complex realUnit() {
		return new Complex(1,0);
	}
	public static Complex imaginaryUnit() {
		return new Complex(0,1);
	}

	public int getRealInt() { return realInt; }
	public int getImagInt() { return imagInt; }
	public double getRealDbl() { return realDbl; }
	public double getImagDbl() { return imagDbl; }
	
	private void convertToDouble() {
		realDbl=realInt; imagDbl=imagInt;
		isInt=false;
	}

	public String toString() {
		if (isInt) {
			return realInt+"+"+imagInt+"j";
		} else {
			return realDbl+"+"+imagDbl+"j";			
		}
	}
	
	public Complex add(Complex b) {
		Complex result;
		boolean resultIsInt=true;
		if (!isInt && b.isInt) {
			b.convertToDouble();
			resultIsInt = false;
		} else if (isInt && !b.isInt) {
			convertToDouble(); // self
			resultIsInt = false;
		} else if (!isInt && !b.isInt) {
			resultIsInt = false;		
		}
		if (resultIsInt) {
			result = new Complex(realInt+b.realInt, imagInt+b.imagInt);
		} else {
			result = new Complex(realDbl+b.realDbl, imagDbl+b.imagDbl);			
		}
		return result;
	}
	public Complex sub(Complex b) {
		Complex result;
		boolean resultIsInt=true;
		if (!isInt && b.isInt) {
			b.convertToDouble();
			resultIsInt = false;
		} else if (isInt && !b.isInt) {
			convertToDouble(); // self
			resultIsInt = false;
		} else if (!isInt && !b.isInt) {
			resultIsInt = false;		
		}
		if (resultIsInt) {
			result = new Complex(realInt-b.realInt, imagInt-b.imagInt);
		} else {
			result = new Complex(realDbl-b.realDbl, imagDbl-b.imagDbl);			
		}
		return result;
	}
	public Complex mul(Complex b) {
		Complex result;
		boolean resultIsInt=true;
		if (!isInt && b.isInt) {
			b.convertToDouble();
			resultIsInt = false;
		} else if (isInt && !b.isInt) {
			convertToDouble(); // self
			resultIsInt = false;
		} else if (!isInt && !b.isInt) {
			resultIsInt = false;		
		}
		if (resultIsInt) {
			result = new Complex(realInt*b.realInt-imagInt*b.imagInt,
					realInt*b.imagInt+b.realInt*imagInt);
		} else {
			result = new Complex(realDbl*b.realDbl-imagDbl*b.imagDbl,
					realDbl*b.imagDbl+b.realDbl*imagDbl);			
		}
		return result;
	}
	public Complex div(Complex b) {
		Complex result;
		if (b.isInt) {
			b.convertToDouble();
		}
		if (isInt) {
			convertToDouble(); // self
		}
		double denominator = (b.realDbl*b.realDbl+b.imagDbl*b.imagDbl);
		result = new Complex(
				(realDbl*b.realDbl+imagDbl*b.imagDbl) / denominator,
				 b.realDbl*imagDbl-realDbl*b.imagDbl / denominator);			
		return result;
	}
	/* overloaded operators like in C++ don't exist in Java:
	public Complex operator_plus(Complex b) {	
		return add(b);
	}
	*/
}
