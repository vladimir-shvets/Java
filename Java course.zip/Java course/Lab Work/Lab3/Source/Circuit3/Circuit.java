/**
 * 
 */
package haw.so2.circuit3;

/**
 * @author Schoenen
 *
 */
public class Circuit {
	private String name;
	private boolean debug=false;
	private VoltageSource u1  = new VoltageSource("U1", 5.0);
	private Resistor r1 = new Resistor("R1",100.0);
	private Capacitor c1 = new Capacitor("C1", 100e-6);
	private AmpMeter meter1 = new AmpMeter("A1");
	double frequency = 50.0;
	public Circuit(boolean debug) {
		this.debug = debug;
		name = "Circuit1";
		if (debug) System.out.println("Circuit() called");
	}
	public String toString() { return name + ": " + meter1; }
	public void calculate() {
		if (debug) System.out.println("calculate() called");
		double u = u1.getVoltage();
		//double r = r1.getResistance();
		Complex z = c1.getImpedance(frequency);
		if (debug) System.out.println("r1 = "+r1);
		if (debug) System.out.println("c1 = "+c1+" => Z="+z);
		//double i = u/r; // Ohm's law
		// i = u / z :
		Complex i = (new Complex(u,0.0)).div(z);
		//meter1.setCurrent(i);
		System.out.println("i = "+i);
	}
}
