/**
 * 
 */
package haw.so2.circuit3;

/**
 * This is the test class
 * @author Schoenen
 *
 */
public class Test {

	public static final boolean debug = true; // global constant

	/**
	 * This is the entry point
	 * @param args
	 */
	public static void main(String[] args) {
		Circuit aCircuit = new Circuit(debug);
		aCircuit.calculate();
		System.out.println(aCircuit);
	}

}
