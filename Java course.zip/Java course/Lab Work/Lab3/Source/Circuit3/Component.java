/**
 * 
 */
package haw.so2.circuit3;

/**
 * @author Schoenen
 *
 */
public abstract class Component {
	private String name;

	/**
	 * @param name
	 */
	public Component(String name) {
		super();
		if (Test.debug) System.out.println("Component("+name+") called");
		this.name = name;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	public String toString() {
		return getComponentType()+" [name=" + getName() + ", "+getValueType()+" = " + getValue() + " " + getUnit() + "]";
	}

	public abstract String getUnit();
	public abstract String getComponentType();
	public abstract String getValueType();
	public abstract double getValue();
	public abstract Complex getImpedance(double frequency);
}
