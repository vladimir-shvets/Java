/**
 * 
 */
package haw.so2.circuit3;

/**
 * @author Schoenen
 *
 */
public class Capacitor extends Component {

	private double capacity;

	@Override
	public String getUnit() {
		return "Farad";
	}
	@Override
	public String getComponentType() {
		return "Capacity";
	}
	@Override
	public String getValueType() {
		return "capacitance";
	}
	@Override
	public double getValue() {
		return capacity;
	}
	@Override
	public Complex getImpedance(double frequency) {
		return new Complex(0.0 , -1.0/(2*Math.PI*frequency*capacity));
	}
	/**
	 * @return the capacity
	 */
	public double getCapacity() {
		return capacity;
	}
	/**
	 * @param capacity the capacity to set
	 */
	public void setCapacity(double capacity) {
		this.capacity = capacity;
	}
	/**
	 * @param name
	 */
	public Capacitor(String string, double d) {
		super(string);
		capacity = d;
		if (Test.debug) System.out.println("Capacitor("+string+", "+d+" "+getUnit()+" called");
	}
}
