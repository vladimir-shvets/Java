/**
 * 
 */
package haw.so2.circuit3;

/**
 * @author Schoenen
 *
 */
public class AmpMeter {

	private String name;
	private double current = 0.0;

	public AmpMeter(String string) {
		name = string;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AmpMeter [name=" + name + ", current=" + current + "]";
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the current
	 */
	public double getCurrent() {
		return current;
	}

	/**
	 * @param current the current to set
	 */
	public void setCurrent(double current) {
		this.current = current;
	}

}
