/**
 * 
 */
package haw.so2.circuit3;

/**
 * VoltageSource
 * @author Schoenen
 *
 */
public class VoltageSource {

	private String name;
	private double voltage;

	public VoltageSource(String string, double d) {
		name = string;
		voltage = d;
		if (Test.debug) System.out.println("VoltageSource("+string+","+d+") called");
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the voltage
	 */
	public double getVoltage() {
		return voltage;
	}

	/**
	 * @param the voltage to set
	 */
	public void setVoltage(double voltage) {
		this.voltage = voltage;
	}

}
