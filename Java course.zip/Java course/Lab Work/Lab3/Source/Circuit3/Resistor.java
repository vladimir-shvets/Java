/**
 * 
 */
package haw.so2.circuit3;

/**
 * Resistor
 * @author Schoenen
 *
 */
public class Resistor extends Component {

	private double resistance;

	@Override
	public String getUnit() {
		return "Ohm";
	}
	@Override
	public String getComponentType() {
		return "Resistor";
	}
	@Override
	public String getValueType() {
		return "resistance";
	}
	@Override
	public double getValue() {
		return resistance;
	}
	@Override
	public Complex getImpedance(double frequency) {
		return new Complex(resistance , 0.0);
	}

	/**
	 * @return the resistance
	 */
	public double getResistance() {
		return resistance;
	}
	/**
	 * @param resistance the resistance to set
	 */
	public void setResistance(double resistance) {
		this.resistance = resistance;
	}

	public Resistor(String string, double d) {
		super(string);
		resistance = d;
		if (Test.debug) System.out.println("Resistor("+string+", "+d+" "+getUnit()+" called");
	}
}
