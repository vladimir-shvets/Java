/**
 * 
 */
//package haw.sol2.ex41_radar;

import java.util.ArrayList;
//import java.util.Iterator;

/**
 * @author Schoenen
 *
 */
public class MovingObjectContainer {
	private static MovingObjectContainer myContainer = null;
	private static ArrayList<MovingObject> myObjects = new ArrayList<>();
	private boolean debug;
	public int myArray;

	
	/**
	 * Private constructor means nobody outside can make an object from this class.
	 * This is the "Singleton" pattern.
	 * You get the singleton handle using a getter method.
	 */
	private MovingObjectContainer(boolean debug) {
		super();
		this.debug = debug;
		if (debug) System.out.println("MovingObjectContainer::constructor()");
	}
	public static MovingObjectContainer getObjectFactory() {
		if (myContainer==null) { // constructor can only be called once:
			myContainer = new MovingObjectContainer(false);
		}
		return myContainer;
	} // getObjectFactory()
	public static MovingObjectContainer getObjectFactory(boolean debug) {
		if (debug) System.out.println("MovingObjectContainer::getObjectFactory(debug="+debug+")");
		if (myContainer==null) { // constructor can only be called once:
			myContainer = new MovingObjectContainer(debug);
		}
		return myContainer;
	} // getObjectFactory(debug)
	
	/**
	 * @param the number of random objects to create and the radius within they are dropped
	 */
	public void createRandomObjects(int howMany, double maxRadius) {
		if (debug) System.out.println("MovingObjectContainer::createRandomObjects("+howMany+","+(int)maxRadius+")");
		//int index = myObjects.size()+1;
		for(int i=1;i<=howMany;i++) {
			MovingObject myObject;
			int type = (int)(Math.random()*4.0); // 0..1 ToDo: change this when you add more cases
			switch(type) {
			case 0:	myObject = new Aircraft(String.format("A%02d", i)); break;
			case 1: myObject = new Ship(String.format("S%02d", i)); break;
			case 2: myObject = new Helicopter(String.format("H%02d", i)); break;
			case 3: myObject = new Sailboat(String.format("SB%02d",i)); break;
			// ToDo: add sailboat, helicopter etc.
			default: myObject = new Aircraft(String.format("A%02d", i)); break;
			}
			myObject.setRandomPosition(maxRadius);
			myObject.setRandomAngle();
			myObject.setTypicalValues();
			myObject.go(); // send them on their path
			myObjects.add(myObject);
		}
	}
	
	/**
	 * @return myObjects
	 */
	public ArrayList<MovingObject> getMyObjects() {
		//if (debug) System.out.println("MovingObjectContainer::getMyObjects(): "+myObjects.size()+" objects.");
		return myObjects;
	}

	/**
	 * @param the objects to add
	 */
	public void addObject(MovingObject object) {
		if (debug) System.out.println("MovingObjectContainer::addObject("+object+")");
		myObjects.add(object);
	}
	
	/**
	 * This calls update for all objects in our collection
	 * @param deltaT is the time change since last update
	 */
	public void updatePosition(double deltaT) {
		// ToDo: implement this
		/*
		for(int i=0;i<myObjects.size();i++)
		{
			MovingObject up = myObjects.get(i);
			up.updatePosition(deltaT);
			
		}
		*/
		
		for(MovingObject obj: myObjects){
			obj.updatePosition(deltaT);
		}
		
	}
	
	public static ArrayList<MovingObject> getArray()
	{
		return myObjects;
	}
	
	/**
	 * This method is complete. Do not change.
	 * @param radarPosition(x,y) and its beam andle
	 */
	public void checkAllReflectedRadar(Vector radarPosition, double radarBeamAngle) {
		//if (debug) System.out.println("MovingObjectContainer::checkAllReflectedRadar("+radarPosition+","+radarBeamAngle+")");
		for(MovingObject myObject : myObjects) {
			boolean newlyDetected = myObject.reflectedRadar(radarPosition, radarBeamAngle);
			if (newlyDetected && debug) System.out.println("MovingObjectContainer: detected new object "+myObject+" @ angle="+radarBeamAngle);
		}
	}
	
}
