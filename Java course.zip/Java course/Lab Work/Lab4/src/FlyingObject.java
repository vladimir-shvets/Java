
public abstract class FlyingObject extends MovingObject {

	public FlyingObject(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
