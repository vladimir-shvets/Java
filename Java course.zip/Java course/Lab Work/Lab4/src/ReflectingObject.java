/**
 * 
 */
//package haw.sol2.ex41_radar;

/**
 * @author Schoenen
 *
 */
public abstract class ReflectingObject {
	protected boolean detected=false;
	private double reflectivity=0.1; // reflected power / arrived power
	/**
	 * constructor
	 */
	public ReflectingObject() {
	}
	
	/**
	 * @return detected or not
	 * meaning: if the radar beam has hit the target object once, it is assumed "detected".
	 */
	public boolean isDetected() {
		return detected;
	}

	/**
	 * @return the reflectivity value
	 */
	public double getReflectivity() {
		return reflectivity;
	}

	@Override
	abstract public String toString(); // must be implemented by derived class
	/**
	 * check if object is in radar beam direction and therefore detected.
	 * We have to check a sector of angles since last check,
	 * since we will never exactly hit the right angle.
	 * If this object was detected, its field "detected" must be set true.
	 * @return true if object has been caught on radar
	 */
	// ToDo: Implement this in the next derived class which knows about locations
	abstract public boolean reflectedRadar(Vector radarPosition, double radarBeamAngle);
}
