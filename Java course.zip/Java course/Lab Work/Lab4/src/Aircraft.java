
public class Aircraft extends FlyingObject {

	public Aircraft(String name) {
		super(name);
		speed = 300;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setTypicalValues() {
		speed = 300;
		
	}

	@Override
	public String toString() {
		
		return name;
	}

}
