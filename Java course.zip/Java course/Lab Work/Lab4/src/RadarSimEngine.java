/**
 * 
 */
//package haw.sol2.ex41_radar;

/**
 * @author Schoenen
 * This class simulates the detection of objects in a 2D space around the radar antenna 
 */
public class RadarSimEngine implements Runnable {
	final private long INTERVAL = 500; // Milliseconds between updates
	final private int NUMBEROFRANDOMOBJECTS = 10; // we generate so many random objects of one type
	private boolean debug;
	private boolean alive=false;
	private boolean running=false;
	private boolean paused=false;
	private String tName; // thread name
	//private double startTime;
	private double lastUpdateTime;
	private double speedup=1; // =simulatedTime/simulationTime
	private double simulatedDeltaT;
	private double simulatedTimeNow;
	private double lastUpdateSimulatedTime=0.0;
	private MovingObjectContainer movingObjects;
	private double lastRadarAntennaAngle=0.0; // east
	private double radarAntennaAngle;
	private double rotationSpeed = 2*Math.PI/60.0; // one turn per 60 seconds
	private Vector location = new Vector(0,0);
	private double metersOfRange = 5000; // 5km for first ring
	/**
	 * constructor
	 */
	public RadarSimEngine(boolean debug) {
		this.debug = debug;
		if (debug) System.out.println("RadarSimEngine() constructor");
		double nowRealTime = System.currentTimeMillis() / 1000.0; lastUpdateTime=nowRealTime; lastUpdateSimulatedTime=0.0; // initialize
		// get the singleton of the object manager (container)
		movingObjects = MovingObjectContainer.getObjectFactory(debug); // aircraft etc.
		//floatingObjects = FloatingObjectContainer.getObjectFactory(); // ships etc.
		// create the moving objects:
		movingObjects.createRandomObjects(NUMBEROFRANDOMOBJECTS,2.0*metersOfRange);
	} // constructor

	/**
	 * thread starting point, inherited from Runnable interface
	 */
	@Override
	public void run() {
		alive=true;
		tName=Thread.currentThread().getName()+"::";
		if (debug) System.out.println(tName+"RadarSimEngine.run() thread starting point");
		while (alive) {
			if (running) {
				eventLoop(); // regular updates inside
			} else {
				try {Thread.sleep(INTERVAL);} catch (InterruptedException e) {e.printStackTrace();}	
			}
		} // alive=false at exit time
		if (debug) System.out.println(tName+"RadarSimEngine.run() thread ends.");
	}
	private void eventLoop() {
		double nowRealTime = System.currentTimeMillis() / 1000.0; lastUpdateTime=nowRealTime; lastUpdateSimulatedTime=0.0; // initialize
		while (running) {
			if (!paused) {
				nowRealTime = System.currentTimeMillis() / 1000.0;
				double deltaTRealTime = nowRealTime - lastUpdateTime;
				simulatedDeltaT = speedup*deltaTRealTime;
				simulatedTimeNow = lastUpdateSimulatedTime + simulatedDeltaT;
				if (debug) System.out.println(tName+String.format("simulated: t=%.3fs, deltaT=%.3fs", simulatedTimeNow, simulatedDeltaT));
				radarAntennaAngle = lastRadarAntennaAngle + rotationSpeed  * simulatedDeltaT;
				if (radarAntennaAngle>2.0*Math.PI) { radarAntennaAngle-=2.0*Math.PI; }
				movingObjects.updatePosition(simulatedDeltaT);
				movingObjects.checkAllReflectedRadar(location, radarAntennaAngle);
				try {Thread.sleep(INTERVAL);} catch (InterruptedException e) {e.printStackTrace();}
				finally {
					lastUpdateTime = nowRealTime; lastUpdateSimulatedTime = simulatedTimeNow;
					lastRadarAntennaAngle = radarAntennaAngle;		
				}
			} else { // paused
				try {Thread.sleep(INTERVAL);} catch (InterruptedException e) {e.printStackTrace();}	
			}
		} // running
	}
	
	/**
	 * start the simulation
	 */
	public void startSim() {
		running=true; paused=false;
		if (debug) System.out.println(tName+"RadarSimEngine.startSim()");
		double nowRealTime = System.currentTimeMillis() / 1000.0; lastUpdateTime=nowRealTime; lastUpdateSimulatedTime=0.0; // back to zero
		radarAntennaAngle=0.0;
	}
	/**
	 * stop the simulation
	 */
	public void stopSim() {
		running=false;
		if (debug) System.out.println(tName+"RadarSimEngine.stopSim()");
		simulatedTimeNow=0.0;
		radarAntennaAngle=0.0;	
	}
	/**
	 * terminate the thread
	 */
	public void exitSim() {
		alive=false;
	}
	/**
	 * @return running or not
	 */
	public boolean isRunning() {
		return running;
	}
	/**
	 * @param pause the simulation
	 */
	//public void pauseSim() {
	//	paused=true;
	//}
	/**
	 * @param toggle pause of the simulation
	 */
	public void togglePause() {
		paused=!paused;
		if (paused) { // flag in eventLoop takes care of pause
		} else { // resume after pause
			// this is the new reference time point now:
			double nowRealTime = System.currentTimeMillis() / 1000.0; lastUpdateTime=nowRealTime;
			// keep lastUpdateSimulatedTime from before when the pause was started
		}
	}
	/**
	 * @return paused or not
	 */
	public boolean isPaused() {
		return paused;
	}
	/**
	 * @return paused or not
	 */
	public boolean isRunningAndNotPaused() {
		//if (debug) System.out.println(tName+"RadarSimEngine.isRunningAndNotPaused(): runnning="+running+",paused="+paused+",return="+(running&&!paused));
		return running&&!paused;
	}
	/**
	 * @return the rotationSpeed
	 */
	public double getRotationSpeed() {
		return rotationSpeed;
	}

	/** change the rotation speed
	 * @param rotationSpeed the rotationSpeed to set
	 */
	public void setRotationSpeed(double rotationSpeed) {
		this.rotationSpeed = rotationSpeed;
	}
	
	/**
	 * @return the movingObjects
	 */
	public MovingObjectContainer getMovingObjects() {
		return movingObjects;
	}

	/**
	 * @return the location
	 */
	public Vector getLocation() {
		return location;
	}

	/** set new location of the radar station
	 * @param location the location to set
	 */
	public void setLocation(Vector location) {
		this.location = location;
	}

	/**
	 * @return the simulated time now
	 */
	private double getSimTime() { // simulated time in seconds
		if (running && !paused) {
			double nowRealTime = System.currentTimeMillis() / 1000.0;
			double deltaTRealTime = nowRealTime - lastUpdateTime;
			simulatedDeltaT = speedup*deltaTRealTime;
			simulatedTimeNow = lastUpdateSimulatedTime + simulatedDeltaT;
			// convert computer time (real time) to simulated time, e.g. 1 second -> 1 day
		} // else take last unchanged simulatedTimeNow from member field
		return simulatedTimeNow;
	}
	public String getSimTimeFormattedString() {
		double simTime = getSimTime(); double remaining=0.0;
		int days    = (int) Math.floor(simTime/24.0/60.0/60.0); remaining = simTime - (double)days*24*60*60;
		int hours   = (int) (remaining/3600.0); remaining -= (double)hours*3600.0;
		int minutes = (int) (remaining/60.0); remaining -= (double)minutes*60.0;
		int seconds = (int) remaining;
		return String.format("%02d:%02d:%02d:%02d",days,hours,minutes,seconds);
	}

	/**
	 * @return the radarAntennaAngle
	 * real-time calculation of the current angle,
	 * without using the simEngine.update()
	 */
	public double getRadarAntennaAngle() {
		if (running && !paused) {
			double nowRealTime = System.currentTimeMillis() / 1000.0;
			double deltaTRealTime = nowRealTime - lastUpdateTime;
			simulatedDeltaT = speedup*deltaTRealTime;
			radarAntennaAngle = lastRadarAntennaAngle + rotationSpeed  * simulatedDeltaT;
		} // else take last unchanged radarAntennaAngle from member field
		return radarAntennaAngle;
	}

	public double getMetersOfRange() {
		return metersOfRange ;
	}

} // RadarSimEngine
