import java.util.ArrayList;

//package haw.sol2.ex41_radar;

public abstract class MovingObject extends ReflectingObject {
	public enum MobilityModel { NONE, RANDOMWALK }
	private double angle;
	private MobilityModel mobilityModel;
	protected double speed;
	private Vector velocity;
	private Vector position;
	protected String name;
	
	// TODO: implement missing methods and add missing fields
	// here:
	
	public MovingObject(String name) {
		this.name = name;
		this.setMobilityModel(MobilityModel.RANDOMWALK);
		// TODO Auto-generated constructor stub
	}
	public void setRandomPosition(double maxRadius) {
		double x,y,z;
		Vector p;
		do { // try within rectangular box and reject
			x = 2.0*(Math.random()-0.5)*maxRadius;
			y = 2.0*(Math.random()-0.5)*maxRadius;
			z = 0.0;
			p = new Vector(x,y,z);
		} while (p.abs() > maxRadius);
		position = p;
	}
	public void setRandomAngle() { // for velocity
		this.angle = Math.random()*2.0*Math.PI;
	}
	public void setMobilityModel(MobilityModel e) {
		this.mobilityModel = e;
	}
	public void go() {
		updateAngle();
	}
	public void updateAngle() {
		double x,y,z;
		x = speed*Math.cos(angle);
		y = speed*Math.sin(angle);
		z = 0.0;
		velocity = new Vector(x,y,z); // speed		
	}
	public void updatePosition(double deltaT) {
		position.addTo(velocity.mul(deltaT));
		if (mobilityModel == MobilityModel.RANDOMWALK) { // change movement
			angle += 2.0*Math.PI*(Math.random() - 0.5)
					 * 0.2; // reduce randomness. Randomness only within smaller sector instead of 360�.
			updateAngle();
		} else if (mobilityModel == MobilityModel.NONE) { // nothing to do
		}
		
		if(position.abs() > 15000){
			detected = false;
			
			ArrayList<MovingObject> arr = new ArrayList();
			arr= MovingObjectContainer.getArray();
			for(int i=0;i<arr.size();i++)
			{
				if(position.abs() > 15000)
				{
					arr.remove(i);
				}
			}
			//MovingObjectContainer.getObjectFactory().getArray();
			
			
		}
	}
	/**
	 * must be implemented by derived classes
	 * depends on their specialties
	 */
	abstract public void setTypicalValues();
	/**
	 * check if object is in radar beam direction and therefore detected.
	 * We have to check a sector of angles since last check,
	 * since we will never exactly hit the right angle.
	 * If this object was detected, its field "detected" must be set true.
	 * @return true if object has been newly caught on radar
	 */
	public boolean reflectedRadar(Vector radarPosition, double radarBeamAngle) {
		final double ANGLETOLERANCE = 5.0*Math.PI/180.0; // +/- 5� tolerance
		if (!this.detected) { // only check new objects
			System.out.println("position = " + position);
			double positionAngle = position.getAngleBetweenInverted(radarPosition);
			//if (true) System.out.println("MovingObject::reflectedRadar("+radarPosition+","+radarBeamAngle+"): pAngle="+positionAngle+", diff="+(Math.abs(positionAngle-radarBeamAngle)));
			if (Math.abs(positionAngle-radarBeamAngle)<ANGLETOLERANCE
					&& position.abs() < 15000) {
				this.detected = true;
				return true; // newly detected for the first time
			}
		} // no need to check again if once detected
		return false;
	}
	public Vector getPosition() {
		// TODO Auto-generated method stub
		return this.position;
	}
	public double getSpeed() {
		
		// TODO Auto-generated method stub
		return this.speed;
	}

}
