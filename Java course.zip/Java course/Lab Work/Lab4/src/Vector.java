/**
 * 
 */
//package haw.sol2.ex41_radar;

/**
 * @author Schoenen
 *
 */
public class Vector {
	public double x,y,z;

	public Vector(double x, double y, double z) {
		super();
		this.x = x;
		this.y = y;
		this.z = z;
	}
	public Vector(double x, double y) {
		super();
		this.x = x;
		this.y = y;
		this.z = 0;
	}
	public Vector() {
		super();
		this.x = 0;
		this.y = 0;
		this.z = 0;
	}
	/**
	 * @return the vector as a string
	 */
	public String toString() {
		return "("+x+","+y+","+z+")";
	}

	/**
	 * @return the x
	 */
	public double getX() {
		return x;
	}

	/**
	 * @param x the x to set
	 */
	public void setX(double x) {
		this.x = x;
	}

	/**
	 * @return the y
	 */
	public double getY() {
		return y;
	}

	/**
	 * @param y the y to set
	 */
	public void setY(double y) {
		this.y = y;
	}

	/**
	 * @return the z
	 */
	public double getZ() {
		return z;
	}

	/**
	 * @param z the z to set
	 */
	public void setZ(double z) {
		this.z = z;
	}
	
	/** get the distance between this and the other vector
	 * @param l is the other vector
	 */
	public double distanceTo(Vector l) {
		return Math.sqrt((x-l.x)*(x-l.x) + (y-l.y)*(y-l.y) + (z-l.z)*(z-l.z));
	}
	/** get the difference vector
	 * @param l is the other vector
	 */
	public Vector differenceVector(Vector l) {
		return new Vector(l.x-x,l.y-y,l.z-z);
	}
	/** get the angle of the difference vector
	 * @param l is the other vector
	 */
	public double getAngleBetween(Vector l) {
		double a = Math.atan2(l.y-y, l.x-x);
		if (a<0) a+=2.0*Math.PI;
		return a;
	}
	/** get the angle of the difference vector
	 * @param l is the other vector
	 */
	public double getAngleBetweenInverted(Vector l) {
		double a = Math.atan2(y-l.y, x-l.x);
		if (a<0) a+=2.0*Math.PI;
		return a;
	}
	/** 
	 *  @return vector multiplied with scalar c 
	 */
	public Vector mul(double c) {
		return new Vector(c*x,c*y,c*z);
	}
	/** 
	 *  @return vector multiplied with scalar c 
	 */
	public void mulWith(double c) {
		x*=c; y*=c; z*=c;
	}
	/** 
	 *  add another vector to this
	 */
	public void addTo(Vector v) {
		x+=v.x; y+=v.y; z+=v.z;
	}
	/** 
	 *  @return Eucledian distance to (0,0,0)
	 */
	public double abs() {
		return Math.sqrt(x*x+y*y+z*z);
	}

}
