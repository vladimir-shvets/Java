
public class Helicopter extends FlyingObject{

	public Helicopter(String name) {
		super(name);
		speed = 100;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setTypicalValues() {
		speed = 100;
		// TODO Auto-generated method stub
		
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name;
	}

}
