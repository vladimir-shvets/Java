//package haw.sol2.ex41_radar;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;
/* the following class is provided by WindowBuilder. It is located in ./org/eclipse/wb/swt/ */
import org.eclipse.wb.swt.SWTResourceManager; // comment this out if you get errors here

/* ^ if commented out this java file must be in your project directory with all the others */
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.GridData;

public class RadarApplication {

	final private int GUIUPDATEINTERVAL = 100; // Milliseconds between updates
	final private int GRIDRADIUS = 100; // pixels

	protected Shell shell;
	protected Display myDisplay;
	private Label labelSimTime;
	private Canvas myCanvas;
	private UpdateThread updateThread;
	private int maxRadius;
	static boolean debug=true; // change to false for production code, after debugging
	static RadarSimEngine simEngine;
	static Thread simThread;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		if (debug) System.out.println("main()");
		try {
			RadarApplication window = new RadarApplication(); // constructor see below
			window.open(); // see below. We stay in here until the window is closed.
		} catch (Exception e) {
			e.printStackTrace(); return; // exit
		}
		simEngine.stopSim(); // stop simulation
		simEngine.exitSim(); // exit thread
		if (debug) System.out.println("Simulation ends.");
		try { simThread.join(); // wait for thread to exit
		} catch (InterruptedException e) { e.printStackTrace();	}
		if (debug) System.out.println("main() ends. Good work! Goodbye.");
	} // main()

	/**
	 * Launch the application.
	 */
	public RadarApplication() { // constructor
		super();
		if (debug) System.out.println("RadarApplication() constructor");
		simEngine = new RadarSimEngine(debug); // our class
		simThread = new Thread(simEngine);
		simThread.start(); // RadarSimEngine.run() will be invoked and runs in parallel to the main thread.
		updateThread = new UpdateThread(); // will be activated by timer events later
	} // constructor

	/**
	 * Open the window.
	 */
	public void open() {
		if (debug) System.out.println("RadarApplication.open()");
		Display display = Display.getDefault();
		myDisplay = display; // member
		createContents(); // see below
		shell.open();
		shell.layout();
		if (debug) System.out.println("RadarApplication.open(): reached event loop");
		System.out.println("Press Start button to begin...");
		while (!shell.isDisposed()) { // event loop
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		//updateThread.kill
	} // open()

	/**
	 * Create contents of the window.
	 * Design done with WindowBuilder/SWT. No manual coding.
	 */
	protected void createContents() {
		if (debug) System.out.println("RadarApplication.createContents()");
		shell = new Shell();
		shell.setSize(724, 684);
		shell.setText("Radar Application");
		GridLayout gl_shell = new GridLayout(2, false);
		gl_shell.marginHeight = 0;
		gl_shell.verticalSpacing = 0;
		gl_shell.horizontalSpacing = 1;
		gl_shell.marginWidth = 0;
		shell.setLayout(gl_shell);
		
		Menu menu = new Menu(shell, SWT.BAR);
		shell.setMenuBar(menu);
		
		MenuItem mntmFile = new MenuItem(menu, SWT.CASCADE);
		mntmFile.setText("File");
		
		Menu menu_1 = new Menu(mntmFile);
		mntmFile.setMenu(menu_1);
		
		MenuItem mntmOpen = new MenuItem(menu_1, SWT.NONE);
		mntmOpen.setText("Open");
		
		MenuItem mntmSave = new MenuItem(menu_1, SWT.NONE);
		mntmSave.setText("Save");
		
		MenuItem mntmWhytext = new MenuItem(menu_1, SWT.SEPARATOR);
		mntmWhytext.setText("whyText");
		
		MenuItem mntmExit = new MenuItem(menu_1, SWT.NONE);
		mntmExit.setText("Exit");
		//Button btnCancel = new Button(shlCheckOut, SWT.NONE);
		mntmExit.addSelectionListener(new SelectionAdapter() {
		        public void widgetSelected(SelectionEvent e) {
		    		System.exit(0);
		        }
		 });
		
		
		MenuItem mntmSimulation = new MenuItem(menu, SWT.CASCADE);
		mntmSimulation.setText("Simulation");
		
		Menu menu_2 = new Menu(mntmSimulation);
		mntmSimulation.setMenu(menu_2);
		
		MenuItem mntmStart = new MenuItem(menu_2, SWT.NONE);
		mntmStart.setText("Start");
		
		mntmStart.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				if (!simEngine.isRunning()) simEngine.startSim();
				//mntmStart.setGrayed(true); mntmStart.setGrayed(false);
				if (debug) System.out.println("scheduling timer event for updateThread");
				myDisplay.timerExec (GUIUPDATEINTERVAL, updateThread);
				mntmStart.setText("Started");
			}
		});
		
	
		MenuItem mntmPause = new MenuItem(menu_2, SWT.NONE);
		mntmPause.setText("Pause");
		mntmPause.setText("Pause");

		
		
		MenuItem mntmStop = new MenuItem(menu_2, SWT.NONE);
		mntmStop.setText("Stop");
		mntmStop.setText("Stop");
		mntmStop.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				if (simEngine.isRunning()) simEngine.stopSim();
				//mntmStop.setGrayed(false); mntmStop.setGrayed(true);
				mntmStop.setText("Stopped");
			}
		});
		
		MenuItem mntmObjects = new MenuItem(menu, SWT.CASCADE);
		mntmObjects.setText("Objects");
		
		Menu menu_3 = new Menu(mntmObjects);
		mntmObjects.setMenu(menu_3);
		
		MenuItem mntmAddObject = new MenuItem(menu_3, SWT.NONE);
		mntmAddObject.setText("Add random object");
		mntmAddObject.addSelectionListener(new SelectionAdapter() {
			
			public void widgetSelected(SelectionEvent arg0) {
				
				MovingObjectContainer.getObjectFactory(debug).createRandomObjects(1,15000);
			}
				
		});
		
		MenuItem mntmAddObject10 = new MenuItem(menu_3, SWT.NONE);
		mntmAddObject10.setText("Add 10 random objects");
		mntmAddObject10.addSelectionListener(new SelectionAdapter() {
			
			public void widgetSelected(SelectionEvent arg0) {
				
				MovingObjectContainer.getObjectFactory(debug).createRandomObjects(10,15000);
			}
				
		});
		
		
		MenuItem mntmHelp = new MenuItem(menu, SWT.NONE);
		mntmHelp.setText("Help");
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, false, false, 1, 1));
		composite.setLayout(null);
		
		Label lblTime = new Label(composite, SWT.NONE);
		lblTime.setBounds(0, 90, 90, 20);
		lblTime.setText("time");
		labelSimTime = lblTime; // member
		
		Label lblStatus = new Label(composite, SWT.NONE);
		lblStatus.setBounds(0, 110, 90, 20);
		lblStatus.setText("status");
		
		Button btnStart = new Button(composite, SWT.NONE); btnStart.setBounds(0,  0, 90, 30);
		Button btnStop  = new Button(composite, SWT.NONE);  btnStop.setBounds(0, 60, 90, 30);
		Button btnPause = new Button(composite, SWT.NONE); btnPause.setBounds(0, 30, 90, 30);
		btnStart.setToolTipText("Click here to start");
		btnStart.setText("Start");
		btnStart.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				if (!simEngine.isRunning()) simEngine.startSim();
				btnStart.setGrayed(true); btnStop.setGrayed(false);
				if (debug) System.out.println("scheduling timer event for updateThread");
				myDisplay.timerExec (GUIUPDATEINTERVAL, updateThread);
				lblStatus.setText("Started");
			}
		});
		btnStop.setToolTipText("Click here to stop");
		btnStop.setText("Stop");
		btnStop.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				if (simEngine.isRunning()) simEngine.stopSim();
				btnStart.setGrayed(false); btnStop.setGrayed(true);
				lblStatus.setText("Stopped");
			}
		});
		btnPause.setToolTipText("Click here to pause/interrupt");
		btnPause.setText("Pause");
		btnPause.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				if (simEngine.isRunning()) { // pause only makes sense when sim is running
					simEngine.togglePause();
					if (!simEngine.isPaused()) { // resume
						btnPause.setText("Pause");
						mntmPause.setText("Pause");
						myDisplay.timerExec (GUIUPDATEINTERVAL, updateThread);
						lblStatus.setText("Resumed");
					} else { // pause mode
						btnPause.setText("Resume");
						mntmPause.setText("Resume");
						lblStatus.setText("Paused");
					}
				}
			}
		});
		
		mntmPause.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				if (simEngine.isRunning()) { // pause only makes sense when sim is running
					simEngine.togglePause();
					if (!simEngine.isPaused()) { // resume
						btnPause.setText("Pause");
						mntmPause.setText("Pause");
						myDisplay.timerExec (GUIUPDATEINTERVAL, updateThread);
						lblStatus.setText("Resumed");
					} else { // pause mode
						btnPause.setText("Resume");
						mntmPause.setText("Resume");
						lblStatus.setText("Paused");
					}
				}
			}
		});
		
		Canvas canvas = new Canvas(shell, SWT.NONE);
		canvas.setLayout(new FillLayout(SWT.HORIZONTAL));
		GridData gd_canvas = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1);
		gd_canvas.heightHint = 270;
		gd_canvas.widthHint = 489;
		canvas.setLayoutData(gd_canvas);
		canvas.addControlListener(new ControlAdapter() {
			@Override
			public void controlResized(ControlEvent arg0) { // called each time the window is resized
				//if (debug) System.out.println("RadarApplication.controlResized()");
			}
		});
		canvas.addPaintListener(new PaintListener() {
			public void paintControl(PaintEvent arg0) {
				if (debug) System.out.println("RadarApplication.paintControl()");
				redrawSpace(canvas);
			}
		});
		canvas.setBackground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		createGrid(canvas);
		myCanvas = canvas; // member
		//myDisplay.timerExec (GUIUPDATEINTERVAL, updateThread); // done in startBtn
	} // createContents()
	/**
	 * Create radar grid.
	 */
	protected void createGrid(Canvas canvas) { // polar coordinate grid
		//if (debug) System.out.println("RadarApplication.createGrid()");
		Rectangle canvasRect = canvas.getClientArea();
		int sizeX = canvasRect.width;
		int sizeY = canvasRect.height;
		int sizeMin = Math.min(sizeX, sizeY);
		Point myCenter = new Point (sizeX/2, sizeY/2);
		canvas.setBackground(myDisplay.getSystemColor (SWT.COLOR_BLACK));
		GC gc = new GC (canvas);
		gc.fillRectangle (0, 0, sizeX, sizeY);
		Color color = new Color(myDisplay, new RGB(0,128,0)); // dim green
		gc.setForeground(color);			
		gc.setBackground(color); // background fill color
		maxRadius = 0;
		double metersPerPixel = simEngine.getMetersOfRange()/GRIDRADIUS;
		for(int radius = GRIDRADIUS; radius<sizeMin/2; radius+=GRIDRADIUS) {
			// gc.fillOval(myCenter.x-radius, myCenter.y-radius, radius*2, radius*2);
			gc.drawOval(myCenter.x-radius, myCenter.y-radius, radius*2, radius*2);
			gc.drawText(String.format("%.0f", radius*metersPerPixel), myCenter.x, myCenter.y+radius, true/*transparent*/);
			maxRadius=radius;
		}
		double gridAngle = Math.PI/6; // 30�
		for(double angle=0; angle<2*Math.PI; angle+=gridAngle) {
			gc.drawLine(myCenter.x, myCenter.y, (int)(myCenter.x+maxRadius*Math.cos(angle)), (int)(myCenter.y-maxRadius*Math.sin(angle)));
		}
		gc.dispose ();
	}
	/**
	 * Plot the radar beam.
	 */
	public void drawBeam(Canvas canvas) {
		double angle = simEngine.getRadarAntennaAngle();
		Rectangle canvasRect = canvas.getClientArea();
		int sizeX = canvasRect.width;
		int sizeY = canvasRect.height;
		Point myCenter = new Point (sizeX/2, sizeY/2);
		GC gc = new GC (canvas);
		Color color = new Color(myDisplay, new RGB(0,255,0)); // bright green
		gc.setForeground(color);			
		gc.drawLine(myCenter.x, myCenter.y, (int)(myCenter.x+maxRadius*Math.cos(angle)), (int)(myCenter.y-maxRadius*Math.sin(angle)));
		gc.dispose ();
	}
	/**
	 * Plot the detected objects.
	 */
	public void drawObjects(Canvas canvas) {
		GC gc = new GC (canvas);
		Rectangle canvasRect = canvas.getClientArea();
		int sizeX = canvasRect.width;
		int sizeY = canvasRect.height;
		Point myCenter = new Point (sizeX/2, sizeY/2);
		double metersPerPixel = simEngine.getMetersOfRange()/GRIDRADIUS; // 50
		MovingObjectContainer movingObjects = simEngine.getMovingObjects();
		//for(MovingObject myObject : movingObjects) {
		for(MovingObject myObject : movingObjects.getMyObjects()) {
			if (myObject.isDetected()) { // only show detected objects
				Vector location = myObject.getPosition();
				//if (debug) System.out.println("RadarApplication.drawObjects(): object="+myObject+" @ "+location);
				Vector locationPixel = location.mul(1.0/metersPerPixel); // scale to pixels
				//if (debug) System.out.println("RadarApplication.drawObjects(): object="+myObject+" @ "+locationPixel);
				// how to draw?
				double speed = myObject.getSpeed();
				int radius = 4;
				if (speed >= 300.0) { //  aircraft
					Color color = new Color(myDisplay, new RGB(200,0,0)); // red
					gc.setForeground(color);			
					gc.drawOval(myCenter.x+(int)locationPixel.getX()-radius, myCenter.y-(int)locationPixel.getY()-radius, 2*radius, 2*radius);
				}  
				if (speed == 100) { // helicopter
					Color color = new Color(myDisplay, new RGB(255,255,255)); // white
					gc.setForeground(color);			
					Rectangle rect = new Rectangle(myCenter.x+(int)locationPixel.getX()-radius, myCenter.y-(int)locationPixel.getY()-radius, 2*radius, 2*radius);
					gc.drawRectangle(rect);
				}
				if (speed == 20) { // ship
					Color color = new Color(myDisplay, new RGB(255,255,0)); // yellow
					gc.setForeground(color);			
					Rectangle rect = new Rectangle(myCenter.x+(int)locationPixel.getX()-radius, myCenter.y-(int)locationPixel.getY()-radius, 2*radius, 2*radius);
					gc.drawRectangle(rect);
				}
				if (speed == 5) { // sailboat
					Color color = new Color(myDisplay, new RGB(255,51,255)); // pink
					gc.setForeground(color);			
					Rectangle rect = new Rectangle(myCenter.x+(int)locationPixel.getX()-radius, myCenter.y-(int)locationPixel.getY()-radius, 2*radius, 2*radius);
					gc.drawRectangle(rect);
				}
				
			gc.drawText(myObject.toString(), myCenter.x+(int)locationPixel.getX(), myCenter.y-(int)locationPixel.getY(), true/*transparent*/);
			} // detected
		} // forall objects
		gc.dispose ();
	}
	/**
	 * Plot everything. For redraw() purpose.
	 */
	public void redrawSpace(Canvas canvas) {
		//if (debug) System.out.println("RadarApplication.redrawSpace()");
		createGrid(canvas);
		drawBeam(canvas);
		drawObjects(canvas);
		String timeString = simEngine.getSimTimeFormattedString();
		labelSimTime.setText(timeString);
	}
	/**
	 * Periodic GUI updates per thread.
	 * This is a class definition within a class definition. Can only be used inside class RadarApplication.
	 */
	class UpdateThread implements Runnable { // periodic GUI updates
		@Override
		public void run () { // thread body
			if (shell.isDisposed ()) return;
			if (simEngine.isRunningAndNotPaused()) {
				if (debug) {
					String timeString = simEngine.getSimTimeFormattedString();
					System.out.println("UpdateThread::run(): time="+timeString);
				}
				//simEngine.update(); // done in separate thread
				redrawSpace(myCanvas);
				myDisplay.timerExec (GUIUPDATEINTERVAL, this);
			} else { // paused simulator
				if (debug) System.out.println("UpdateThread: idle because simEngine is off");
				// do not reschedule timer event
			}
		}		
	} // class UpdateThread
} // class RadarApplication