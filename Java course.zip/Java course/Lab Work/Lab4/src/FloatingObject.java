
public abstract class FloatingObject extends MovingObject{

	public FloatingObject(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
