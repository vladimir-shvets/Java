
public class Ship extends FloatingObject {

	public Ship(String name) {
		super(name);
		speed = 20;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setTypicalValues() {
		speed = 20;
		// TODO Auto-generated method stub

	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name;
	}

}
