import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;

public class Sailboat extends FloatingObject{

	public Sailboat(String name) {
		super(name);
		speed = 5;
		//Color color = new Color(myDisplay, new RGB(0,0,200)); // blue
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setTypicalValues() {
		speed = 5;
		// TODO Auto-generated method stub
		
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name;
	}

}
