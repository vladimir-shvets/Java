/**
 * JUnit demo/test code
 * Start either with
 * 1) "Run As" .. "JUinit Test". No need for main()
 * 2) "Run As" .. "Java Application". Uses main() which runs all tests inside as well
 *  
 *  
 * assertArrayEquals(java.lang.Object[] expecteds, java.lang.Object[] actuals)
   Asserts that two object arrays are equal.
 * assertEquals(double expected, double actual, double delta)
   Asserts that two doubles or floats are equal to within a positive delta.
 * assertFalse(boolean condition)
 * assertNotNull(java.lang.Object object)
 * assertNull(java.lang.Object object)
 * assertSame(java.lang.Object expected, java.lang.Object actual)
   Asserts that two objects refer to the same object.
 * assertThat(T actual, org.hamcrest.Matcher<T> matcher)
   Asserts that actual satisfies the condition specified by matcher.
 * assertTrue(boolean condition)
 * fail()
   Fails a test with no message.
 * fail("message")
   Fails a test with a message.
 */
//package haw.sol2.ex21_filesystem;
// if this shows an error in Eclipse, choose "fix project setup" as solution to include the JUnit4 library.
import org.junit.Assert;
//import static org.junit.Assert.*; // using this line means we can use assertTrue() directly without Assert.assertTrue()
import org.junit.Before;
import org.junit.BeforeClass;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Test;
import org.junit.Ignore;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

/**
 * @author Prof. Rainer Schoenen
 *
 */
public class TestClass {
	private CheckFilesystem testObject;
	private static ArrayList<String> listOfDirs;
	private static boolean debug = false; // flag to control debug output on/off
	// @BeforeClass block is executed only once before all tests.
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		CheckFilesystem.debug = debug; // overwrite static member
		if (debug) System.out.println("setUpBeforeClass");
		String [] startDirs = {"C:\\Users\\All Users"}; // to start with while debugging
		ArrayList<String> listOfDirs = new ArrayList<String>();
		for(String myDir : startDirs) { // iterate
			listOfDirs.add(myDir); // insert into variable-size list.
		}
		TestClass.listOfDirs = listOfDirs; // static
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		if (debug) System.out.println("tearDownAfterClass");
		TestClass.listOfDirs = null;
	}
	// @Before block is executed before each and any specific test.
	@Before
	public void setUp() throws Exception {
		if (debug) System.out.println("setUp");
		CheckFilesystem.debug = debug;
		CheckFilesystem.verbose = false;
		//testObject = new CheckFilesystem(listOfDirs);
		testObject = new CheckFilesystem(listOfDirs);
	}
	@After
	public void tearDown() throws Exception {
		if (debug) System.out.println("tearDown");
		testObject = null;
	}
	// @Test is an annotation for JUnit to mark test cases (unit tests):
	@Test
	public void testListOfDirs(){
		if (debug) System.out.println("testPredefinedObject()");
		Assert.assertNotNull("testObject not null",listOfDirs);
		Assert.assertFalse("listOfDirs.isEmpty()",listOfDirs.isEmpty());
		Assert.assertTrue("listOfDirs.size()",listOfDirs.size()>0);
		//Assert.assertEquals("correct field2",testObject.getField2(), 3e8, 1e-6);
	}
	@Test
	public void testConstruktor1(){
		if (debug) System.out.println("testConstruktor1()");
		Assert.assertNotNull("testObject not null",testObject);
		Assert.assertTrue("listOfDirs.size()",testObject.getListOfDirs().size()>0);
		try {
			testObject.doCheck();
		} catch (Exception e){
			Assert.fail("unexpected "+e);
		}
	}
	@Test
	public void testDirectoryChecker(){
		if (debug) System.out.println("testDirectoryChecker()");
		DirectoryChecker myCheck = new DirectoryChecker(debug);
		try { 
			myCheck.startCheck(listOfDirs); // main functionality in here
		} catch (IOException ex) {
			ex.printStackTrace();
			Assert.fail("unexpected "+ex);
		} finally { // cleanup
			if (debug)
				System.out.println("Log:\n"+myCheck.getLog()); // print logging output
		}
	}
	@Test
	public void testDirectoryChecker2(){
		if (debug) System.out.println("testDirectoryChecker2()");
		DirectoryChecker myCheck = new DirectoryChecker(debug);
		try { 
			myCheck.startCheck(listOfDirs); // main functionality in here
		} catch (IOException ex) {
			ex.printStackTrace();
			Assert.fail("unexpected "+ex);
		} finally { // cleanup
			if (debug)
				System.out.println("Log:\n"+myCheck.getLog()); // print logging output
		}
		Set<String> allExtensions = myCheck.getAllFileExtensions();
		if (debug) System.out.println("getAllFileExtensions()="+allExtensions.size());
		Assert.assertTrue("getAllFileExtensions().size() must be >10",allExtensions.size()>10);
		for(String myExtension : allExtensions) { // iterate
			int seenHowOften = myCheck.getNumberOfFilesOfExtension(myExtension);
			Assert.assertTrue("getNumberOfFilesOfExtension("+myExtension+") must be >0",seenHowOften>0);
		}
	}
	@Ignore("this will run in a future release")
	@Test(timeout=2000) // must run within 2 seconds
	public void testFutureFeature(){
	}
	/**
	 * main block executes all JUnit tests first.
	 * @param args
	 */
	 // "Run As" .. "JUinit Test". No need for main()
	public static void main(String[] args) {
		debug = true; // to turn on verbose output during tests.
		Result rs = JUnitCore.runClasses(TestClass.class);
		for (Failure fail : rs.getFailures())
			System.out.println(fail.getMessage()+": "+fail.getTestHeader());
	}
}
