/** Interface Class: THe methods declared here must be implemented in the derived class
 * 
 */
//package haw.sol2.ex21_filesystem;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;

/**
 * @author Schoenen
 * Interface for class that iterates through filesystem
 */
public interface CheckerInterface {
	public void startCheck(ArrayList<String> listOfDirs) throws IOException;
	public String getLog();
	public Set<String> getAllFileExtensions(); 
	public int getNumberOfFilesOfExtension(String myExtension);
}
