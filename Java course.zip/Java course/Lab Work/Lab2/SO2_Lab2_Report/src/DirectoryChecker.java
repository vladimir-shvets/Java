import java.io.File;
import java.io.IOException;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

//import javax.naming.ldap.ExtendedRequest;
//import java.util.*;



public class DirectoryChecker implements CheckerInterface {
	private Directory directory;
	private int NumberNullPointerExceptions = 0;
	private Date date;
	private DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
	
	//constructor of the DirectoryChecker class
	public DirectoryChecker(boolean debug) {
		directory = new Directory();
		date = new Date();
	}

	//function which goes through all list of directories and implements the paths into the files
	@Override
	public void startCheck(ArrayList<String> listOfDirs) throws IOException {
		try{
			for (String dirpath : listOfDirs)
			{	
				Path path = Paths.get(dirpath);
				File folder = path.toFile();
				if(folder.isDirectory())
					collectAllFilesForFolder(folder);	
			}
		}catch(InvalidPathException e){
				System.out.println("\nInvalid dir path!\n\n");
		}finally{
			System.out.println("Total number of collected files: " + directory.getAllFilesCount());
		}
	}
	
	//recursively goes through all folder and collect all directories and files names
	public void collectAllFilesForFolder(File folder)
	{
		
		// check if the folder.listfiles() does not return null
		// and catch the exception in this way
		try{
			File[] folderFiles = folder.listFiles();
			
			for (File file : folderFiles)
			{
					if(file.isDirectory())
					{	
						directory.allDirectories.add(file);
						collectAllFilesForFolder(file); //recursive going through the whole tree of directories
					}
					else
					{
							directory.allFiles.add(file);
					}
					
			}
		}catch(NullPointerException e){
			//System.out.println("Exception thrown: " + e.getMessage());
			NumberNullPointerExceptions++; //calculate the number of the catched exceptions
		}		
	}
	

	//print out the start, finish time and the duration of the executing the program
	@Override
	public String getLog() {
		Date dateFinish = new Date();
		System.out.println("\nchecking started: " + dateFormat.format(date));
		System.out.println("checking finished: " + dateFormat.format(dateFinish));
		
		long timeDiff = dateFinish.getTime() - date.getTime();
		long diffSeconds = timeDiff/1000 %60;
		long diffMinutes = timeDiff/(60*1000) % 60;
		long diffHours = timeDiff/(60*60*1000);
		
		if(diffSeconds < 10 && diffMinutes < 10)
			System.out.println("duration: 0" + diffHours + ":0" + diffMinutes + ":0" + diffSeconds);
		else if(diffSeconds > 10 && diffMinutes < 10)
			System.out.println("duration: 0" + diffHours + ":0" + diffMinutes + ":" + diffSeconds);
		else if(diffSeconds < 10 && diffMinutes > 10)
			System.out.println("duration: 0" + diffHours + ":" + diffMinutes + ":0" + diffSeconds);
		else if(diffSeconds > 10 && diffMinutes > 10)
			System.out.println("duration: 0" + diffHours + ":" + diffMinutes + ":" + diffSeconds);
			
		
		System.out.println("-------------------------------------");
		
		if(NumberNullPointerExceptions > 0) //print out the TOTAL number of the founded exceptions
			return "Excepteions thrown : " + NumberNullPointerExceptions;
		else
			return ""; //otherwise print nothing
	}

	//collect all extensions into Set(no duplicates)
	@Override
	public Set<String> getAllFileExtensions() {
		//if(directory.allFiles.isEmpty())	
		//	return null;
		Set<String> extensions = new HashSet<String>();
		
		// check if there is no null-files
		//and if such situation happens try...catch block catch the exception
		try{
		
		for (File file : directory.allFiles)
		{			
			int i = file.getName().lastIndexOf('.');
			if (i > 0)
			{
				extensions.add(file.getName().substring(i));
			}
		}
		}catch(NullPointerException e){
			System.out.println("Exception thrown" + e.getMessage());
		}			
		return extensions;	
		
	}

	//get the total number of files which contains certain extension
	@Override
	public int getNumberOfFilesOfExtension(String myExtension) {
		int counter = 0;
		for (File file : directory.allFiles)
		{
			if (file.getName().contains(myExtension))
				counter++;
		}
		return counter;
	}
	
	//calculate the number of files which consists NON-ASCII symbols 
	public int getNumberOfNonAsciiFIles()
	{
		int counter = 0;
		for(File file : directory.allFiles)
		{
			if(!file.getName().matches("\\A\\p{ASCII}*\\z")) //regular expression to check for ASCII symbols
				counter++;
		}
		return counter;
	}
	
	// print out the percentage of the NON-ASCII files according to the whole amount of files
	public void getPercentageNumberofNonAsciiFiles()
	{
		System.out.format("%.2f", getNumberOfNonAsciiFIles()*100./directory.getAllFilesCount());
	}
		
	
}
