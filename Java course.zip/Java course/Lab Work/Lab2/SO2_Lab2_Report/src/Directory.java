import java.io.File;
import java.util.ArrayList;

/**
 * @author Michael
 *
 */

public class Directory extends AbstractDirectory {

	/* (non-Javadoc)
	 * @see AbstractDirectory#getAllFilesCount()
	 */
	
	//AbstractDirectory()
	@Override
	public int getAllFilesCount() {
		return allFiles.size();
	}

	/* (non-Javadoc)
	 * @see AbstractDirectory#getAllFiles()
	 */
	@Override
	public ArrayList<File> getAllFiles() {
		if(allFiles.isEmpty())
			return null;
		else
			return allFiles;
	}

	/* (non-Javadoc)
	 * @see AbstractDirectory#getAllDirectoriesCount()
	 */
	@Override
	public int getAllDirectoriesCount() {
		return allDirectories.size();
	}

}
