/**
 * 
 */
//package haw.sol2.ex21_filesystem;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;

/**
 * @author Prof. Schoenen
 * learning outcome of this exercise:
 * be able to handle the following concepts:
 * - arrays and Collections classes (e.g. ArrayList)
 * - iterators
 * - private members and public methods
 * - interface classes
 * - debugging, breakpoints, debugger, ...
 * - API for files
 * - try/catch
 * - derived classes
 */

// CheckFilesystem class
public class CheckFilesystem {	
	public static boolean debug = true;
	public static boolean verbose = true;
	private ArrayList<String> listOfDirs;
	public CheckFilesystem(ArrayList<String> listOfDirs) { // Constructor
		if (debug) System.out.println("CheckFilesystem() Constructor");
		this.listOfDirs = listOfDirs;
		int count=0; // print list elements:
		for(String myDir : listOfDirs) { // iterate
			if (verbose) System.out.printf("Dir[%d]=\"%s\"\n",count++,myDir);
		}
	}
	public ArrayList<String> getListOfDirs() { return listOfDirs; }
	public void doCheck() {
		
		DirectoryChecker myCheck = new DirectoryChecker(debug);
		
		//myCheck.startCheck(listOfDirs); // main functionality in here
		try { 
			myCheck.startCheck(listOfDirs); // main functionality in here
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally { // cleanup
			if (debug)
				System.out.println("Log:\n"+myCheck.getLog()); // print logging output
		}
		
		//print the number of files which contains Non-ASCII symbols
		System.out.print("numberOfNonAsciiFiles: " + myCheck.getNumberOfNonAsciiFIles() + "(");
		myCheck.getPercentageNumberofNonAsciiFiles();
		System.out.print("%)\n");
		
		// get all obtained file extensions
		Set<String> allExtensions = myCheck.getAllFileExtensions();
		if (verbose) System.out.println("Recognized "+allExtensions.size()+" file name extensions.");
		int count=0; // print list elements:
		for(String myExtension : allExtensions) { // iterate
			int seenHowOften = myCheck.getNumberOfFilesOfExtension(myExtension);
			if (verbose) System.out.printf("Ext[%d]=\"%s\": %d times\n",count++,myExtension,seenHowOften);
		}
		
	}
	
	//Main
	public static void main(String[] args) {
		// main test program
		if (debug) System.out.println("CheckFilesystem");
		//String [] startDirs = {"C:\\Windows"}; // to start with while debugging
		//String [] startDirs = {"C:\\"};
		String [] startDirs = {"C:\\", "D:\\", "E:\\"}; // for the final version
		//String [] startDirs = {"L:\\"}; // the network drive on the lab PC
		ArrayList<String> listOfDirs = new ArrayList<String>();
		for(String myDir : startDirs) { // iterate
			listOfDirs.add(myDir); // insert into variable-size list.
		}
		if (args.length>0) {
			String anotherDir=""; // use input from command line
			for(int i = 0; i < args.length; i++) {
				anotherDir = args[i];
				listOfDirs.add(anotherDir); // insert into variable-size list.
	        }
		}
		if (debug) System.out.println("listOfDirs has "+listOfDirs.size()+" entries:");
		CheckFilesystem checkFilesystem = new CheckFilesystem(listOfDirs);
		checkFilesystem.doCheck();
	} // end of main
} // end of class
