/**
 * 
 */
//package haw.sol2.ex21_filesystem;

import java.io.File;
import java.util.ArrayList;

/**
 * @author Schoenen
 * Template class for derived class Directory.
 * Initializes the required internal collection variables
 */
public abstract class AbstractDirectory {
	protected boolean debug = true;
	protected ArrayList<File> allFiles;
	protected ArrayList<File> allDirectories;

	// this constructor initializes the members and must be called by derived class
	public AbstractDirectory() {
		//if (debug) System.out.println("AbstractDirectory() constructor");
		allFiles = new ArrayList<File>();
		allDirectories = new ArrayList<File>();
	}

	// The following three methods must be implemented by just one line of code inside!
	// Hint: Use the above declared fields allFiles and allDirectories.
	public abstract int getAllFilesCount();
	public abstract ArrayList<File> getAllFiles(); // can be used to recursively get all files of all dirs
	public abstract int getAllDirectoriesCount();

}
