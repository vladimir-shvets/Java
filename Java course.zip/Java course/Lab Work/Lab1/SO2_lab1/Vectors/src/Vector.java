
/**
 *
 * @author Michael
 */
public class Vector {
    private double x, y, z;  
    private int xInt, yInt, zInt;
    boolean isInt;
  
    //Constructor for integer numbers
    public Vector(int x, int y, int z, boolean isInt)
    {
        this.xInt = x;
        this.yInt = y;
        this.zInt = z;
        this.isInt = isInt;
    }
    
    //Constructor for double numbers
    public Vector(double x, double y, double z, boolean isInt)
    {
        this.x = x;
        this.y = y;
        this.z = z;
        this.isInt = isInt;
    }
    
    //Method which returns the current condition (true = numbers are integers, false - doubles) 
    public boolean isInteger()
    {
        return this.isInt;
    }
    
    // Add two vectors
    public Vector sum(Vector v2)
    {
        boolean flag = (this.isInt && v2.isInteger()); // flag stores the condition for output vector 
        Vector v3 = new Vector(0,0,0, flag);
        
        if (flag) // if flag == true, then work with integer numbers
        {
            v3.xInt = this.xInt + v2.xInt;
            v3.yInt = this.yInt + v2.yInt;
            v3.zInt = this.zInt + v2.zInt;
        }
        else  // if flag == false, then work with double numbers
        {
            v3.x = ((this.isInt) ? this.xInt : this.x) + ((v2.isInt) ? v2.xInt : v2.x);
            v3.y = ((this.isInt) ? this.yInt : this.y) + ((v2.isInt) ? v2.yInt : v2.y);
            v3.z = ((this.isInt) ? this.zInt : this.z) + ((v2.isInt) ? v2.zInt : v2.z);
        }
        
        return v3;
    }
    
    public String toString() //convert vector to the string
    {
        if (this.isInt) // if value of boolean variable isInt == true, then output like integer numbers
            return "(" + this.xInt + ", " + this.yInt + " ," + this.zInt + ")";
        else // otherwise output like doubles
            return "(" + this.x + ", " + this.y + " ," + this.z + ")";
    }
    
    public void Output() //output to the screen
    {
        System.out.println("Output: " + toString());
    }
    
    // Subtract two vectors
    public Vector sub(Vector v2)
    {
        boolean flag = (this.isInt && v2.isInteger());
        Vector v3 = new Vector(0,0,0, flag);
        
        if (flag)
        {
            v3.xInt = this.xInt - v2.xInt;
            v3.yInt = this.yInt - v2.yInt;
            v3.zInt = this.zInt - v2.zInt;
        }
        else
        {
            v3.x = ((this.isInt) ? this.xInt : this.x) - ((v2.isInt) ? v2.xInt : v2.x);
            v3.y = ((this.isInt) ? this.yInt : this.y) - ((v2.isInt) ? v2.yInt : v2.y);
            v3.z = ((this.isInt) ? this.zInt : this.z) - ((v2.isInt) ? v2.zInt : v2.z);
        }
        
        return v3;
    }
    
    //Scalar multiplication of two vectors
    public Object mulScalar(Vector v2) //return value is Object which means that it will return integer
    {                                  //for integer numbers and double for doubles
        boolean flag = (this.isInt && v2.isInteger());
        Vector v3 = new Vector(0,0,0, flag);
        
        if (flag)
        {
            v3.xInt = this.xInt * v2.xInt;
            v3.yInt = this.yInt * v2.yInt;
            v3.zInt = this.zInt * v2.zInt;
            
             return v3.xInt + v3.yInt + v3.zInt;
        }
        else
        {
            v3.x = ((this.isInt) ? this.xInt : this.x) * ((v2.isInt) ? v2.xInt : v2.x);
            v3.y = ((this.isInt) ? this.yInt : this.y) * ((v2.isInt) ? v2.yInt : v2.y);
            v3.z = ((this.isInt) ? this.zInt : this.z) * ((v2.isInt) ? v2.zInt : v2.z);
        
            return v3.x + v3.y + v3.z;
        }
          
       
    }
    
    // Static addition of two vectors
    public static Vector sum(Vector v1, Vector v2)
    {
        boolean flag = (v1.isInteger() && v2.isInteger());
        Vector v3 = new Vector(0,0,0, flag);
        
        if (flag)
        {
            v3.xInt = v1.xInt + v2.xInt;
            v3.yInt = v1.yInt + v2.yInt;
            v3.zInt = v1.zInt + v2.zInt;
        }
        else
        {
            v3.x = ((v1.isInt) ? v1.xInt : v1.x) + ((v2.isInt) ? v2.xInt : v2.x);
            v3.y = ((v1.isInt) ? v1.yInt : v1.y) + ((v2.isInt) ? v2.yInt : v2.y);
            v3.z = ((v1.isInt) ? v1.zInt : v1.z) + ((v2.isInt) ? v2.zInt : v2.z);
        }
        
        return v3;
    }
    
    // Static subtraction of two vectors
    public static Vector sub(Vector v1, Vector v2)
    {
        boolean flag = (v1.isInteger() && v2.isInteger());
        Vector v3 = new Vector(0,0,0, flag);
        
        if (flag)
        {
            v3.xInt = v1.xInt - v2.xInt;
            v3.yInt = v1.yInt - v2.yInt;
            v3.zInt = v1.zInt - v2.zInt;
        }
        else
        {
            v3.x = ((v1.isInt) ? v1.xInt : v1.x) - ((v2.isInt) ? v2.xInt : v2.x);
            v3.y = ((v1.isInt) ? v1.yInt : v1.y) - ((v2.isInt) ? v2.yInt : v2.y);
            v3.z = ((v1.isInt) ? v1.zInt : v1.z) - ((v2.isInt) ? v2.zInt : v2.z);
        }
        
        return v3;
    }
    
    // Static scalar multiplication of two vectors
    public static Object mulScalar(Vector v1, Vector v2)
    {
        boolean flag = (v1.isInteger() && v2.isInteger());
        Vector v3 = new Vector(0,0,0, flag);
        
        if (flag)
        {
            v3.xInt = v1.xInt * v2.xInt;
            v3.yInt = v1.yInt * v2.yInt;
            v3.zInt = v1.zInt * v2.zInt;
            return v3.xInt + v3.yInt + v3.zInt;
        }
        else
        {
            v3.x = ((v1.isInt) ? v1.xInt : v1.x) * ((v2.isInt) ? v2.xInt : v2.x);
            v3.y = ((v1.isInt) ? v1.yInt : v1.y) * ((v2.isInt) ? v2.yInt : v2.y);
            v3.z = ((v1.isInt) ? v1.zInt : v1.z) * ((v2.isInt) ? v2.zInt : v2.z);
            return v3.x + v3.y + v3.z;
        }
    }
}
