
/**
 *
 * @author Michael
 */
public class Main {
   
    public static void main(String[] args)
    {
        
        System.out.println("29.03.2016 R0813-9 Kulakov Michael, Shvets Vladimir");
        //create examples of class Vector
        Vector v1 = new Vector(1.2, 2.2, 3.5, false); 
        Vector v2 = new Vector(4.15, 5., 1.5, false);
        Vector v3;
        
        //Output the vectors to the screen
        System.out.println("First vector: ");
        v1.Output();
        System.out.println("Second vector: ");
        v2.Output();
           
        //Addition
        v3 = v1.sum(v2);
        System.out.println("Summa ");
        v3.Output();
        
        //Subtraction
        v3 = v1.sub(v2);
        System.out.println("Substraction ");
        v3.Output();
        
        //Scalar Multiplication
        System.out.println("mulScalar: " + v1.mulScalar(v2));
        
        //Static addition
        v3 = Vector.sum(v1, v2);
        System.out.println("Static summa: ");
        v3.Output();
        
        //Static subtraction
        v3 = Vector.sub(v1, v2);
        System.out.println("Static substraction: ");
        v3.Output();
        
        //Static scalar Multiplication
        System.out.println("Static mulScalar: " + Vector.mulScalar(v1, v2));
         
    }
}
