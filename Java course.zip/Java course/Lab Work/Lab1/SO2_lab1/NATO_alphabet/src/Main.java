
import java.util.Scanner;

/**
 *
 * @author Michael
 */
//import java.util.Scanner;

public class Main {
    
    public static void main(String[] args)
    {
        Scanner reader = new Scanner(System.in);
        
        Converting str = new Converting();
        int key = 0;
        
        System.out.println("29.03.2016 R1365-09 Kulakov Michael, Shvets Vladimir\n");
        
        //Print simple menu for user-friendly interface
        System.out.println("Main");
        System.out.println("1 - Translation");
        System.out.println("2 - Reverse translation");
        System.out.println("0 - Exit");
        
        System.out.println("Choose the option: ");
        key = Integer.parseInt(reader.nextLine());
        
        while (key != 0)
        {
            switch(key)
            {
                case 1: 
                {
                   System.out.println("Input word for translation: ");
                   String word = reader.nextLine(); // store into the variable word the value from the keyboard
        
                    int i = 0;
                    System.out.println("Translation: ");
                    while (i < word.length())
                    {
                        System.out.println(str.convert(word.charAt(i))); //read char by char and call the convert() function
                        i++;
                    } break;    
                }
                
                case 2:
                {
                    System.out.println("Input word for reverse_translation: ");
                    String reverseWord = reader.nextLine(); // store into the variable word the value from the keyboard
                    reverseWord = reverseWord.toLowerCase();
        
                    String[] parts = reverseWord.split(" "); //divide the user`s input string into separate words
        
                    for (String item : parts)
                        System.out.println(str.reverse_convert(item)); //reverse translation from character to the Telephony code
                } break;
                
                default: System.out.println("Error command!!"); 
            }
            System.out.println("");
            System.out.println("Main");
            System.out.println("1 - Translation");
            System.out.println("2 - Reverse translation");
            System.out.println("0 - Exit");
            
            System.out.println("Choose the option: ");
            key = Integer.parseInt(reader.nextLine());
        }
        reader.close();
        
    }
}
