
/**
 *
 * @author Michael
 */

public class NATO_alphabet {
    private String[] alphabet = new String[36];
    
        public String[] alphabet()
        {
            this.alphabet[0] = "alfa";
            this.alphabet[1] = "bravo";
            this.alphabet[2] = "charlie";
            this.alphabet[3] = "delta";
            this.alphabet[4] = "echo";
            this.alphabet[5] = "foxtrot";
            this.alphabet[6] = "golf";
            this.alphabet[7] = "hotel";
            this.alphabet[8] = "india";
            this.alphabet[9] = "juliett";
            this.alphabet[10] = "kilo";
            this.alphabet[11] = "lima";
            this.alphabet[12] = "mike";
            this.alphabet[13] = "november";
            this.alphabet[14] = "oscar";
            this.alphabet[15] = "papa";
            this.alphabet[16] = "quebec";
            this.alphabet[17] = "romeo";
            this.alphabet[18] = "sierra";
            this.alphabet[19] = "tango";
            this.alphabet[20] = "uniform";
            this.alphabet[21] = "victor";
            this.alphabet[22] = "whiskey";
            this.alphabet[23] = "xray";
            this.alphabet[24] = "yankee";
            this.alphabet[25] = "zulu";
            this.alphabet[26] = "one";
            this.alphabet[27] = "two";
            this.alphabet[28] = "three";
            this.alphabet[29] = "four";
            this.alphabet[30] = "five";
            this.alphabet[31] = "six";
            this.alphabet[32] = "seven";
            this.alphabet[33] = "eight";
            this.alphabet[34] = "nine";
            this.alphabet[35] = "zero";
           
            return this.alphabet;
          }
}
