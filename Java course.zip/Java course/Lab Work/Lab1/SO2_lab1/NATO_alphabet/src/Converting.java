/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Michael
 */

public class Converting {
    NATO_alphabet test = new NATO_alphabet();
    
    
    // Function which translate Characters into Telephony code
    public String convert(char symbol)
    {
        //compare ASCII code
        if((int)symbol == 48) // symbol = 0; 
            return this.test.alphabet()[(int)symbol - 13];
        if((int)symbol >= 49 && (int)symbol <= 57) // symbols are 1 ... 9
            return this.test.alphabet()[(int)symbol - 23];
        if ((int)symbol >= 97 && (int)symbol <= 122) // lower case letters a...z
            return this.test.alphabet()[(int)symbol - 97];
        if ((int)symbol >= 65 && (int)symbol <= 90) // upper case letters A...Z
            return this.test.alphabet()[(int)symbol - 65];
        
        return "You entered the wrong symbol!"; // Otherwise output the error message
    }
    
    //Function which reverse translate Telephony code into Characters
    public char reverse_convert (String str) //str is the separate telephony code from user`s input string  
    {
        int i = 0; // iterator which runs through the alphabet
        int position = -1; //store the index of founded word at the alphabet which accorded to inputed Telephony code word
        
            while (i < this.test.alphabet().length)
            {
                if (this.test.alphabet()[i].equals(str))
                {
                    position = i;
                    break;
                }     
                i++;
            }
            if (position == -1)
                return '!'; //when the word was inputed incorrect
            if (position == 35) // if inputed Telephony code was "Zero"
                return (char)(position + 13);
            else if (position > 25) // position which is accorded to "One", ... "Nine"
                return (char)(position + 23);
            else return this.test.alphabet()[position].charAt(0); // position which is accorded to "Alfa", ... "Zulu"
    }
}
