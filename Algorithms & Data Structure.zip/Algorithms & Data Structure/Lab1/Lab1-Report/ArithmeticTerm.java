
import java.util.Stack;
import java.util.StringTokenizer;

public class ArithmeticTerm {
    private String input;
    
    public ArithmeticTerm(String input) {
        this.input = input;
    }

    public static void main(String[] args) {
        String str1 = "8.8 2.2 0.2 4.5 * / +";
        //3+2 = 5; 1-5;
        
        //some examples
        /* 1 2 3 + -
         * 8.8 2.2 0.2 4.5 * / +
         * 2 5 ^ 2 6 ^ +
         * ( ( 8.8 / 2.2 ) 0.2 )
        */
        
        ArithmeticTerm arithm = new ArithmeticTerm(str1);
        
        Double result = arithm.evaluate();
        str1.toString();
        System.out.println(str1);
        System.out.println(result);
    }

    //Override the toString() output method
    public String toString() {
        return this.input;
    }
    
    //output the string reverse
    public void reverse() {
        String reverseStr = "";
        Stack<String> reverse = new Stack<String>();
        
        StringTokenizer strTok = new StringTokenizer(this.input, " ");
        //while loop until end of the String push word into stack
        while(strTok.hasMoreTokens()) {
            reverse.push(strTok.nextToken());
        }
        //read out from the stack
        while(!reverse.isEmpty()) {
            reverseStr +=  reverse.pop() + " ";
        }
        //print reversed string
        System.out.println(reverseStr);
    }
    
    //Assignment 1.main function to calculate the result
    public Double evaluate() {
        Stack<Double> numbers = new Stack<Double>();
        StringTokenizer strTok = new StringTokenizer(this.input, " ");
        String tempStr = "";
        //while loop while there is more elements in string(tokens)
        while(strTok.hasMoreTokens()) {
            tempStr = strTok.nextToken();//write to temp variable
            if(this.isDouble(tempStr)) {//if element is converted to double
                numbers.push(Double.valueOf(Double.parseDouble(tempStr)));
            } else if(this.isOperator(tempStr)) {//if operator
                Double tempNumb;
               //to make subtract operation
                    tempNumb = numbers.pop();
                   
                numbers.push(this.CalculateExpression((Double)numbers.pop(), tempStr, tempNumb));
            } else {
                System.out.println("ERROR!");
            }
        }

        if(numbers.size()>1) {
            System.out.println("ERROR!Too much numbers! Please check the input expression!");
            /*  */
        }

        return (Double)numbers.pop();
    }
    //Function return which operator was read form input expression
    public boolean isOperator(String str) {
        return str.equals("+") || str.equals("-") || str.equals("*") || str.equals("/") || str.equals("^");
    }
    //Function which check if read element could be converted to Double type    
    public boolean isDouble(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } 
        catch (NumberFormatException var3) {
            return false;
        }
    }

    //To each mathematical operator there is each mathematical operation
    public Double CalculateExpression(Double first, String op, Double second) {
        Double result;
        switch(op) 
        {
        case "*":
        	result = first * second;
        
            break;
            
        case "+":
        	result = first + second;
            
            break;
        
        case "-":
        	result = first - second;
            
            break;
        
        case "/":
        	result = first / second;
            
            break;
            
        case "^":
        	result = Math.pow(first, second);
            
            break;
        default:
        	System.out.println("Wrong operator!");
        	result = Double.valueOf(0.0D);
        }
		return result;
}
}
