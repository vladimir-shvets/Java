//this class is used for realization of functions, which we will use futher
public class Helper {
    private int value;

    public int getValue()
    {
        return value;
    }

    public int inc()
    {
        return value++;
    }

    public Helper(int startValue)
    {
        value = startValue;
    }
}
