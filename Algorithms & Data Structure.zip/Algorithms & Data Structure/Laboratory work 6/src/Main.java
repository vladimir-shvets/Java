public class Main {
    public static void main(String[] args)
    {
    	//preparation
        PrefixFreeDecoder prep_string = new PrefixFreeDecoder("****kbl_***cta*of");
        String s1 = "a_flock_of_bat_of_a_block_of_flat_of_lot_of_a_cat_flab_a_flat_cab";
        String prep_encode = prep_string.encode(s1);
        System.out.println("Preparation task:");
        System.out.println("Encoding of the string: 'a_flock_of_bat_of_a_block_of_flat_of_lot_of_a_cat_flab_a_flat_cab': \n" + prep_encode + "\n");


        //Problem 12
        PrefixFreeDecoder string_problem12 = new PrefixFreeDecoder("********sam'_hop****tdck*re"); 
        String s2 = "sam's_shop_stocks_short_spotted_socks";
        String problem12_encoded = string_problem12.encode(s2);
        System.out.println("Problem 12");
        System.out.println("Encoding of the string: 'sam's_shop_stocks_short_spotted_socks': \n" + problem12_encoded);

    }
}
