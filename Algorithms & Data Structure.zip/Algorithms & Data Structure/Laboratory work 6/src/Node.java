import java.util.HashMap;


public class Node
    {
		//basic class, where the algorithm of the Node path is described
        char ch;
        Node left, right;//declaring variables, which will be used for left and right node values
        Node(String sequence, HashMap<Character, String> table, String path, Helper counter)
        //algorithm of "Reading" the tree, which is based on recursive calling. The algorithm is working in a way
        //going through the tree. If we found a symbol '*', which means, that we in a node, first we read out left node, after the right node
        // but, in reading left and right side of the node we are calling Node itself, which is recursive method of realization.
        // futher we will call again the same piece of code and the verification if the read character is a '*' will happen.
        {
            if (counter.getValue() == sequence.length())
                return;
            ch = sequence.charAt(counter.inc());
            if (ch == '*')
            {
                left = new Node(sequence, table, path + '0', counter);
                right = new Node(sequence, table, path + '1', counter);
            }
            else
                table.put(ch, path);
        }
        boolean isInternal() {
            return ch == '*';
        }
    }