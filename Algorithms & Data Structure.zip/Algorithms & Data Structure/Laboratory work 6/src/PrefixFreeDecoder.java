import java.util.HashMap;

public class PrefixFreeDecoder {
    private Node root;
    private HashMap<Character, String> table = new HashMap<Character, String>();

    //constructor
    public PrefixFreeDecoder(String string)
    {
        root = new Node(string, table, "", new Helper(0));
    }
    //encoding method
    public String encode(String string_encode)
    {
        String encoded_string = "";
        for(int i = 0; i < string_encode.length(); ++i)//loop, which is working until we reach the end of the string
            encoded_string += table.get(string_encode.charAt(i));// 
        return encoded_string;
    }
    //decoding method
    public void decode(String string_encode)
    {
        int pos = 0;
        while(pos < string_encode.length())//loop, which is working until reaching the end 
        {
            Node x = root;
            while (x.isInternal())// calling of the function, which checks the existence of the '*'
            {
                char bit = string_encode.charAt(pos++);
                if (bit == '0') x = x.left;
                else if (bit == '1') x = x.right;
            }
            System.out.print(x.ch);
        }
    }
}
