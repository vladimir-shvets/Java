//does not work!!!
public class RandomizedBST<Key extends Comparable<Key>, Value>
						 
{
	private Node root;
	
	private class Node
	{
		Key key;
		Value val;
		Integer N = 1;
		//Integer repeat = 1;
		Node left, right;
		
		Node(Key key, Value val)
		{
			this.key = key;
			this.val = val;
		}
	}
	
	//get the number of repetitions of the certain node
	public Value get(Key key)
	{
		Node x = root;
		while (x != null)
		{
			int cmp = key.compareTo(x.key);
			
			if(cmp == 0) 	return x.val;
			if(cmp <  0)	x = x.left;
			if(cmp >  0)	x = x.right;
		}
		
		return null;
	}
	
	private Node rotL(Node h)
	{
		Node v = h.right;
		h.right = v.left;
		v.left = h;
		return v;
	}
	
	private Node rotR(Node h)
	{
		Node u = h.left;
		u.left = h.right;
		u.right = h;
		return u;
	}
	
	public void fixSize(Node x)
	{
		if(x == null) return;
		x.N = 1 + size(x.left) + size(x.right);
	}
	
	public int size(Node x)
	{
		if(x == null) return 0;
		else return x.N;
	}
	
	private Node putRoot(Node x, Key key, Value val)
	{
		if(x == null) return new Node(key, val);
		
		System.out.println(x.key);
		int cmp = key.compareTo(x.key);
		if(cmp == 0) x.val = val;
		else if(cmp < 0)
		{
			x.left = putRoot(x.left, key, val);
			x = rotR(x);
		}
		else if(cmp > 0)
		{
			x.right = putRoot(x.right, key, val);
			x = rotL(x);
		}
	
		return x;
	}
	
	public void put(Key key, Value val)
	{
		root = put(root, key, val);
	}
	
	//think about this -> read info -> find solution
	private Node put(Node x, Key key, Value val)
	{
		if(x == null) return new Node(key, val);
		int cmp  = key.compareTo(x.key);
		if(cmp == 0)
		{
			x.val = val;
			return x;
		}
		
		if(StdRandom.bernoulli(1.0 / (x.N + 1.0)))
			return putRoot(x, key, val);
		
		if(cmp < 0 ) x.left = put(x.left, key, val);
		else if(cmp > 0) x.right = put(x.right, key, val);
		x.N++;
		
		return x;
	}
	
	public int depth()
	{
		return getHeight();
	}
	
	public int getHeight()
	{  
		return getHeight(root);
	}
	
	public int getHeight(Node x)
	{
		if(x == null)
		{
			return -1;
		}
		return 1 + Math.max(getHeight(x.left), getHeight(x.right));
	}
	
}
