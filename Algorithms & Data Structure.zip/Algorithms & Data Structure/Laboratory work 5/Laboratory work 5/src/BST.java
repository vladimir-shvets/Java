import java.util.Iterator;
import java.util.Stack;

public class BST<Key extends Comparable<Key>> 
				     implements Iterable<Key>
{

	@Override
	public Iterator<Key> iterator() {
		return new BSTIterator();
	}

	private Node root;
	
	private class Node
	{
		Key key;
		Integer repeat = 1; //the amount of repetitions of the certain word(node) at the text
		Integer depth;
		Node left, right;
		
		/*Node(Key key)
		{
			this.key = key;
			this.val = 0;
			this.compar = 0;
		}*/
		
		Node(Key key, Integer depth)
		{
			this.key = key;
			//this.repeat = repeat;
			this.depth = depth;
		}
	}
	
	//get the depth of the certain node
	public Integer get(Key key)
	{
		Node x = root;
		while (x != null)
		{
			int cmp = key.compareTo(x.key);
			
			if(cmp == 0) 	return x.depth;
			if(cmp <  0)	x = x.left;
			if(cmp >  0)	x = x.right;
		}
		
		return null;
	}
	
	//get the number of repetitions during the text of a certain node
	public Integer getRepeat(Key key)
	{
		Node x = root;
		while (x != null)
		{
			int cmp = key.compareTo(x.key);
			
			if(cmp == 0) 	return x.repeat;
			if(cmp <  0)	x = x.left;
			if(cmp >  0)	x = x.right;
		}
		
		return null;
	}
	
	public void put(Key key)
	{
		root = put(root, key, 0);
	}
	
	public Node put(Node x, Key key, Integer depth)
	{
		if (x == null) 	return new Node(key, depth);
		
		int cmp = key.compareTo(x.key);
		if(cmp == 0) 		x.repeat++; //calculate the number of repetitions		//x.val = val;
		else if(cmp <  0)	x.left = put(x.left, key, ++depth);
		else if(cmp >  0)	x.right = put(x.right, key, ++depth);
		
		return x;
	}
	
	public int getHeight()
	{  
		return getHeight(root);
	}
	
	public int getHeight(Node x)
	{
		if(x == null)
		{
			return 0;
		}
		return 1 + Math.max(getHeight(x.left), getHeight(x.right));
	}
	
	public class BSTIterator implements Iterator<Key>
	{
		private Stack<Node> stack = new Stack<Node>();
		
		private void pushLeft(Node x)
		{
			while (x != null)
			{
				stack.push(x);
				x = x.left;
			}
		}
		
		
		
		BSTIterator()
		{
			pushLeft(root);
		}
		
		@Override
		public boolean hasNext() {
			return !stack.isEmpty();
		}

		@Override
		public Key next() {
			Node x = stack.pop();
			pushLeft(x.right);
			//System.out.println(x.key + "   --> № repeat: " + x.repeat + "   --> level: " + x.depth);
			return x.key ;
		}
		
	}
	
}
