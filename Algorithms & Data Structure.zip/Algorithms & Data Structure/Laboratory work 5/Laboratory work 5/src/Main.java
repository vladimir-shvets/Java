import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;



public class Main {
	
	/*public static void main(String[] args)
	{
		BST<String, Integer> bst = new BST<String, Integer>();
		
		bst.put("it", 0);
		bst.put("was", 0);
		bst.put("the", 0);
		bst.put("best", 0);
		bst.put("day", 0);
		
		Iterator<String> itr = bst.iterator();
		while(itr.hasNext())
		{
			itr.next();
		}
	}*/
	
	
	
	public static void main(String[] args)
	{
		int flag = 0; //flag = 0 - BST class; 
				      //flag = 1 - Randomized class
		
		switch(flag)
		{
		case 0:
			/*
			 *   ###BST class and all BST class features############################
			 */
		    BST<String> bst = new BST<String>();

		    //Read file to the BufferedReader
		    try
		    { 
		    	BufferedReader br = new BufferedReader(new FileReader("text.txt"));
		    	String singleLine = null;
		    	
		    	while((singleLine = br.readLine()) != null)
		    	{
		    		if (singleLine.equals("")) continue;
		    		String[] words = singleLine.split("[^A-Za-z0-9']+");
		    		
		    		for(String item : words)
		    		{
		    			bst.put(item);
		    		}
		    	}
		    	 
		    }catch(IOException e)
		    {
		    	e.printStackTrace();
		    }
			
			//get the depth of the BST
			int height = bst.getHeight();
		//	System.out.println(bst.getHeight());
			
			
			//get the average depth and standard deviation
			int amountOfNodes = 0;
			int sum = 0;
			int currentDepth = 0;
			//array which contains all depths as indexes and the number of nodes at 
			//each depth level as value
			int amountOfDepths[] = new int[height]; 
			
			Iterator<String> itr = bst.iterator();
			System.out.print(outputfixedString("NODES", 20));
			System.out.print(outputfixedString("DEPTH", 10));
			System.out.println(outputfixedString("REPEAT", 10));
			
			String temp = "";
			while(itr.hasNext())
			{
				temp = itr.next();
				System.out.print(outputfixedString(temp, 20));
				System.out.print(outputfixedString(bst.get(temp).toString() ,10));
				System.out.println(outputfixedString(bst.getRepeat(temp).toString(), 10));
			}
			
			
			System.out.println("\n");
			
			for(String item : bst)
			{
				amountOfNodes++;
				currentDepth = bst.get(item);
				
				sum += currentDepth;
				
				amountOfDepths[currentDepth]++;
			}
			
			
			double mean = (double) sum / amountOfNodes;
			
			double variance = 0;	
			 
			//double relativeNumberOfNodes[] = new double[height];
			
			System.out.print(outputfixedString("DEPTH LEVEL", 20));
			System.out.println(outputfixedString("AMOUNT", 20));
			
			for (int i = 0; i < amountOfDepths.length; i++)
			{
				System.out.print(outputfixedString(Integer.toString(i), 20));
				System.out.println(outputfixedString(Double.toString(amountOfDepths[i]), 20));
				
				variance += Math.pow((mean - i), 2) * amountOfDepths[i];
			}
			
			for(int i = 0; i < amountOfDepths.length; i++)
			{
				System.out.print(outputfixedString(Integer.toString(i), 5));
				System.out.println(outputfixedString(new String("|" + new String(new char[amountOfDepths[i]]).replace("\0", "-") + " (" + amountOfDepths[i] + ")"), 70 ));
			}
			
			
			double standardDeviation = Math.sqrt(variance/amountOfNodes);
			System.out.println("Number of nodes: " + amountOfNodes);
			System.out.printf("Average depth: %.3f ", mean);
			System.out.printf("\nStandard deviation: %.3f ", standardDeviation);
			
			//write data to the file to build up the histogram
			try{
			    PrintWriter writer = new PrintWriter("histogram.txt", "UTF-8");
			    writer.println("Depth level \t Amount");
			    for(int i = 0; i < amountOfDepths.length; i++)
			    {
			    	writer.println("   " + i + "\t\t" + amountOfDepths[i]);
			    }
			    writer.close();
			} catch (IOException e) {
			   e.printStackTrace();
			}
			/*
			 * #### END of the BST class realization ################################
			 */
			break;
			
		case 1:
			/*
			 * #### RandBST class #############################################
			 */
			//RandomizedBST<String, Integer> randBST = new RandomizedBST<>();
			RandBST<String, Integer> randBST = new RandBST<>();
			
			int numbOfNodes = 0;
			int k = 2;
			int currDepth = 0;
			int n = getPowerOf2(k);
		    
			
			
			//Read file to the BufferedReader
		    try
		    { 
		    	BufferedReader br = new BufferedReader(new FileReader("big.txt"));
		    	String singleLine = null;
		    	
		    	System.out.print(outputfixedString("NUMBER OF NODES", 20));
		    	System.out.println(outputfixedString("DEPTH", 20));
		    	
		    	while((singleLine = br.readLine()) != null)
		    	{
		    		if (singleLine.equals("")) continue;
		    		String[] words = singleLine.split("[^A-Za-z0-9']+");
		    		
		    		for(String item : words)
		    		{
		    			randBST.put(item, 0);
		    			
		    			numbOfNodes = randBST.getNumberOfNodes();
		    			
		    			if(numbOfNodes == n)
		    			{
		    				currDepth = randBST.depth();
		    				System.out.print(outputfixedString(Integer.toString(n), 20));
		    				System.out.println(outputfixedString(Integer.toString(currDepth), 20));
		    				
		    				n = getPowerOf2(k += 2);
		    			}
		    		}	
		    		
		    	}
		    		    	
		    	 
		    }catch(IOException e)
		    {
		    	e.printStackTrace();
		    }
		    
		    System.out.println("Number of Nodes : " + randBST.getNumberOfNodes());
		    
		    /*
			 * #### END of the RandomizedBST class realization ################################
			 */
			break;
		}	
		
	}
	
	public static int getPowerOf2(int k)
	{
		return (int) (Math.pow(2, k) - 1);
	}
	
	public static String outputfixedString(String string, int length) 
	{
	    return String.format("%1$-"+length+"s", string);
	}
	
	
}
