
import java.util.NoSuchElementException;

public class PQmin<Key extends Comparable<Key>> {
  
  private Key[] a;  // store elements at indices 0 to n
  private int n;    // number of elements in the priority queue
  

  public PQmin(int capacity) {
    a = (Key[]) new Comparable[capacity + 1];
    n = 0;
  }
  

  public PQmin() {
    this(1);
  }
  
  
  public void insert(Key v) { // method which allows to insert elements, depend on length
    if (n == a.length - 1) resize(a.length * 2);
    a[++n] = v;
    swim(n);
  }
  
  
  public Key delMin() { // method, which delete the less element in the array
    if (n == 0) {
      throw new NoSuchElementException();
    }
    Key min = a[1];
    exch(1, n--);
    sink(1);
    a[n+1] = null;
    
    if ((n > 0) && (n == (a.length - 1) / 4)) resize(a.length / 2);
    return min;
  }

  public boolean isEmpty() {// mehtod which checks if our array is not empty
	    return n == 0;
	  }
  
  private void swim(int k)// method which is need to put the element up if it was at the "bottom" of the tree
  {
	    while (k > 1 && less(k, k / 2)) {
	      exch(k, k / 2);
	      k = k / 2;
	    }
  }

  private void resize(int capacity) {// function to double the size of the heap array
    Key[] temp = (Key[]) new Comparable[capacity];
    for (int i = 0; i <= n; i++) {
      temp[i] = a[i];
    }
    a = temp;
  }
  

  private void sink(int k) {// method which is need to put the element down(sink) if it was at the top of the tree
    while (2 * k <= n) {
      int j = 2 * k;
      if (j < n && less(j+1, j)) j++;
      if (less(k, j)) break;
      exch(k, j);
      k = j;
    }
  }
  
  private boolean less(int i, int j) { // method which could be used in comparable equations to find the less element
      return a[i].compareTo(a[j]) < 0;
  }
  
  private void exch(int i, int j) { // implementation of swap function
    Key temp = a[i];
    a[i] = a[j];
    a[j] = temp;
  }
}
