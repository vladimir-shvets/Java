import java.util.Random;

public class Main {
  private static Random random = new Random();
  
 //method, problem 7.1
  private static void genarate_sorting() {
    System.out.println("Problem 7.1"); // welcome string 
    // variables declaration
    PQmin<Integer> pq = new PQmin<>(100);
    int n = 100, tmp;
    System.out.print("Inserted: ");
    //generate random values insert on his place
    for (int i = 1; i <= n; i++) {
      tmp = random.nextInt(n);
      pq.insert(tmp);
      System.out.print(tmp + " ");
    }
    //pull out elements from the array
    System.out.print("\nSorted: ");
    while (!pq.isEmpty()) {
      System.out.print(pq.delMin() + " ");
    }
    System.out.println();
  }
  
  
 // problem 7.2
  private static void arrayresize() {
    System.out.println("\nProblem 7.2");// welcome message
    // variables declaration
    PQmin<Integer> pq = new PQmin<>();
    int prev_pq, current_pq;
    int n = 10000;
    boolean isequal = true;
    
    //generating random number and writing them to the array
    System.out.println("Generated " + n + " numbers");
    for (int i = 1; i <= n; i++) {
      pq.insert(random.nextInt(n));
    }
    
    //cleaning the memory after generated numbers. Not to crash the RAM of computer :)
    System.out.println("All " + n + " elements have been sucesfully deleted!");
    prev_pq = Integer.MIN_VALUE;
    while (!pq.isEmpty()) {
      current_pq = pq.delMin();
      if (prev_pq > current_pq) 
      {
        isequal = false;
      }
      prev_pq = current_pq;
    }
    
  }
  public static void main(String args[]) {
	    genarate_sorting();
	    arrayresize();

	  }
 
}
