import java.util.Random;

public class Generator {
	public String[] generate(int N, int length)
	{
		Random random = new Random();
		char[] alphabet = { 
				'A',
				'B',
				'C',
				'D',
				'E',
				'F',
				'G',
				'H',
				'I',
				'J',
				'K',
				'L',
				'M',
				'N',
				'O',
				'P',
				'Q',
				'R',
				'S',
				'T',
				'U',
				'V',
				'W',
				'X',
				'Y',
				'Z',
				'a',
				'b',
				'c',
				'd',
				'e',
				'f',
				'g',
				'h',
				'i',
				'j',
				'k',
				'l',
				'm',
				'n',
				'o',
				'p',
				'q',
				'r',
				's',
				't',
				'u',
				'v',
				'w',
				'x',
				'y',
				'z'
				};
		
		String[] strings = new String[N];
		char[] array = new char[length];
		for(int i=0;i<N;i++)//заполняем кол-во строк
		{
			for(int j=0;j<length;j++)//генерируем случайные символы в строку
			{
				int random_index = random.nextInt(51);
				array [j] = alphabet[random_index];
			}
			strings[i] = new String(array);
		}
		return strings;
		
	}
	
}
