
public class Insertion {	
	
	

	public static void sort(Comparable[] a)
	{
		SortHelper.resetCounters();
		
		int N = a.length;
		
		for(int i=1;i<N;i++)
		{
			for(int j = i; j>0;j--)
			{
				if(SortHelper.less(a[j],a[j-1]))
					SortHelper.exch(a,j,j-1);
				else 
					break;
			}
		}
	}

	
}
