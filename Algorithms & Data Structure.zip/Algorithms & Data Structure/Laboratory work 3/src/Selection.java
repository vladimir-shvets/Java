
public class Selection {
	

	public static void sort(Comparable[] a)
	{
		
		SortHelper.resetCounters();
		
		int N = a.length;
		for (int i = 0; i < N; i++)
		{
		int min = i;
		for (int j = i+1; j < N; j++)
		   if (SortHelper.less(a[j], a[min])) min = j;
		if(i != min) SortHelper.exch(a, i, min);
		}
		
	}
	
	
	
	
	
}
