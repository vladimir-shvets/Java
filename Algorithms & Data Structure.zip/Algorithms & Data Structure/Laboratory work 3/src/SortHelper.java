
public class SortHelper {

	public static int comparisons = 0;
	public static int operations = 0;
	
	public static void resetCounters(){
		comparisons = 0;
		operations = 0;
	}
	
	public static int getComparisons(){
		return comparisons;
	}
	
	public static int getOperations(){
		return operations;
	}
	
	public static void comparison(){
		comparisons++;
	}
	
	public static void operation(){
		operations++;
	}
	
	public static boolean less(Comparable v, Comparable w)
	{
		comparison();
		return (v.compareTo(w) < 0);
	}
	

	public static void exch(Comparable[] a, int i, int j)
	{
		Comparable t = a[i];
		a[i] = a[j];
		a[j] = t;
		
		operation();
	}
}
