import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Stack;

public class Main {
	
	public static enum sortings
	{
		INSERTION,
		SELECTION,
		MERGE
	}
	
	public static enum cases
	{
		AVERAGE,
		BEST,
		WORST
	}
	
	public static void reverse(String[] strings)
	{
		Stack<String> stack = new Stack<String>();
		for(String s:strings)
		{
			stack.push(s);
		}
		int i = 0;
		while(!stack.isEmpty()){
			strings[i++] = stack.pop();
		}
		
	}
	
	public static void sort(sortings sort_type, cases c, String[] strings, PrintWriter writer)
	{
		
		switch(sort_type){
			case INSERTION:
				switch(c){
					case AVERAGE:
						Insertion.sort(strings);
						break;
					case BEST:
						Insertion.sort(strings);
						Insertion.sort(strings);
						break;
					case WORST:
						Insertion.sort(strings);
						reverse(strings);
						Insertion.sort(strings);
						break;
					default:
						return;
				}
				
				break;
			
			case SELECTION:
				switch(c){
				case AVERAGE:
					Selection.sort(strings);
					break;
				case BEST:
					Selection.sort(strings);
					Selection.sort(strings);
					break;
				case WORST:
					Selection.sort(strings);
					reverse(strings);
					Selection.sort(strings);
					break;
				default:
					return;
				}
				break;
				
			case MERGE:
				switch(c){
				case AVERAGE:
					Merge.sort(strings);
					break;
				case BEST:
					Merge.sort(strings);
					Merge.sort(strings);
					break;
				case WORST:
					Merge.sort(strings);
					reverse(strings);
					Merge.sort(strings);
					break;
				default:
					return;
				}
				break;
		
		}
		
		println(writer, 
				""+ strings.length
				+ ", " + SortHelper.getComparisons()
				+ ", " + SortHelper.getOperations()
				);
				
	}
	
	public static void println(PrintWriter writer, Object o)
	{
		System.out.println(String.valueOf(o));
		if(writer != null)
		{
			writer.println(String.valueOf(o));
		}
	}
	
	
	
	public static void main(String[] args)
	{
		
		String filename = "report.csv";
		Generator generate = new Generator();
		// average - когда сгенерирован
		// worst - когда задом наперед
		// best - когда уже отсортрован
		PrintWriter writer = null;
		try {
			writer  = new PrintWriter(new FileWriter(filename));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int maxK = 10;
		
		for(sortings type: sortings.values()){
			println(writer,"");
			println(writer,type);
			
			for(cases c: cases.values()){
				println(writer,"");
				println(writer,c);
				println(writer, "LENGTH, COMPARISONS, OPERATIONS");
				for(int k = 1; k <= maxK; k++){
					
					int N = (int) Math.pow(2,k);//увеличение размера строки от 2 до 1024
					String[] strings = generate.generate(N,10);//генерируем случайные строки в зависимости от размера
					
					sort(type, c, strings, writer);
				}
			}
		}
		
		if(writer != null){
			writer.close();
		}
		
	}
	
}
