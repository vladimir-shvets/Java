
public class BiNode {
	public String content;
	public BiNode left;
	public BiNode right;
	
	public BiNode(String content) {
		this(content, null, null);
	}
	
	public BiNode(String content, BiNode left, BiNode right) {
		this.content = content;
		this.left = left;
		this.right = right;
	}
	
	
}
