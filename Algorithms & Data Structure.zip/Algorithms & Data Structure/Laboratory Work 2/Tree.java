import java.util.Stack;

public class Tree {
	private BiNode root;
	private String input = "";
	
	//Constructors
	public Tree(BiNode root) {
		this.root = root;
	}
	public Tree(String postfix){
		this.root = this.construct(postfix);
	}
	
	
	private void visitNode(BiNode node){
		System.out.println(node.content);
	}
	

	//postorder Traversal Method
	private void postOrderTraversal(BiNode node){
		if(node.left != null) postOrderTraversal(node.left);
		if(node.right != null) postOrderTraversal(node.right);
		System.out.println("visit() " + node.content);
		//visitNode(node);
	}
	//Recursive method postOrderTravsal 
	public void postOrderTraversal(){
		this.postOrderTraversal(this.root);
	}
	
	

	//Problem 1. Method which constructs a binary tree form a postFix String
	private BiNode construct(String postFix){
		Stack<BiNode> stack = new Stack<BiNode>();
		String[] inputs = postFix.split(" ");
		for (String x : inputs) { //make a loop, which read the input string and split it by space 
			if(isOperator(x)){// if read symbol is a operator
			
				BiNode right = stack.pop();
				BiNode left = stack.pop();
				stack.push(new BiNode(x,left,right));
			} else {
				stack.push(new BiNode(x));
			}
		}
		return stack.pop();	
	}
	
	//Method, which checks whether the given string is operator
		private static boolean isOperator(String ch) {
			return ch.equals("*") || ch.equals("/") || ch.equals("+") || ch.equals("-")  || ch.equals("^");
		}

	//Main function
	public static void main(String[] args) {

		Tree trail = new Tree("5 4 3 + *");
		System.out.println("Given expression: \n(5 * ( 4 + 3 )) \n");
		
		System.out.println("Problem 3. Postorder:");
		trail.postOrderTraversal();
	}
	
}